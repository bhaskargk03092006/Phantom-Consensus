import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from sanitizer import sanitize_id, sanitize_proposal_id
from cleaner import parse_and_clamp_float
from deduplicator import deduplicate_by_id, DeduplicationStrategy

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Proposal:
    id: str
    title: str
    sponsor_id: str
    priority: float
    metadata: Dict[str, Any] = field(default_factory=dict, compare=False, repr=False)


def _normalize_text(value: Any, default: str = '') -> str:
    if value is None:
        return default
    return str(value).strip()


def _parse_priority(value: Any) -> float:
    parsed, was_clamped = parse_and_clamp_float(value, min_val=0.0, max_val=100.0, default=0.0, field_name='priority')
    return parsed


def parse_proposal(record: Dict[str, Any]) -> Optional[Proposal]:
    if not isinstance(record, dict):
        logger.warning('Skipping proposal record that is not a JSON object: %r', record)
        return None

    proposal_id = sanitize_proposal_id(_normalize_text(record.get('id') or record.get('proposal_id') or record.get('bill_id')))
    title = _normalize_text(record.get('title') or record.get('name'))
    sponsor_id = sanitize_id(_normalize_text(record.get('sponsor_id') or record.get('sponsor') or record.get('sponsoring_representative')))
    priority = _parse_priority(record.get('priority') or record.get('priority_level') or 0.0)

    if not proposal_id or not title:
        logger.warning('Skipping invalid proposal record without id or title: %r', record)
        return None

    metadata = {
        key: value
        for key, value in record.items()
        if key not in {'id', 'proposal_id', 'bill_id', 'title', 'name', 'sponsor_id', 'sponsor', 'sponsoring_representative', 'priority', 'priority_level'}
    }

    return Proposal(
        id=proposal_id,
        title=title,
        sponsor_id=sponsor_id,
        priority=priority,
        metadata=metadata,
    )


def load_proposals(filepath: str, deduplicate: bool = True) -> List[Proposal]:
    path = Path(filepath).expanduser()
    try:
        with path.open('r', encoding='utf-8') as file:
            raw = json.load(file)
    except FileNotFoundError:
        logger.error("Failed to load proposals: file '%s' not found.", filepath)
        return []
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse JSON in '%s'. Error: %s", filepath, exc)
        return []
    except Exception as exc:
        logger.error("Unexpected error while loading proposals from '%s': %s", filepath, exc)
        return []

    if isinstance(raw, dict):
        raw = raw.get('proposals', raw.get('data', raw))

    if not isinstance(raw, list):
        logger.error("Expected JSON array or object with a 'proposals' key in '%s'.", filepath)
        return []

    proposals: List[Proposal] = []
    for item in raw:
        proposal = parse_proposal(item)
        if proposal is not None:
            proposals.append(proposal)

    logger.info('Loaded %d proposals from %s.', len(proposals), filepath)
    
    if deduplicate and len(proposals) > 0:
        proposals = deduplicate_by_id(
            proposals,
            id_getter=lambda p: p.id,
            strategy=DeduplicationStrategy.HIGHEST_PRIORITY,
            priority_getter=lambda p: p.priority
        )
        logger.info('After deduplication: %d unique proposals.', len(proposals))
    
    return proposals


def index_proposals_by_id(proposals: List[Proposal]) -> Dict[str, Proposal]:
    return {proposal.id: proposal for proposal in proposals}


def deduplicate_proposals(proposals: List[Proposal], strategy: DeduplicationStrategy = DeduplicationStrategy.HIGHEST_PRIORITY) -> List[Proposal]:
    """
    Deduplicate a list of already-loaded proposals.
    
    Args:
        proposals: List of proposal objects
        strategy: Deduplication strategy (default: keep highest priority)
        
    Returns:
        List of deduplicated proposals
    """
    if not proposals:
        return []
    
    return deduplicate_by_id(
        proposals,
        id_getter=lambda p: p.id,
        strategy=strategy,
        priority_getter=lambda p: p.priority
    )


if __name__ == '__main__':
    example_path = Path(__file__).parent.parent.parent / 'data' / 'proposals.json'
    proposals = load_proposals(str(example_path))
    for proposal in proposals[:20]:
        print(proposal)
