import logging
from typing import Any, Tuple, Optional

logger = logging.getLogger(__name__)


DEFAULT_INFLUENCE_MIN = 0.0
DEFAULT_INFLUENCE_MAX = 100.0
DEFAULT_INFLUENCE_VALUE = 0.0


def parse_and_clamp_influence(
    value: Any,
    min_val: float = DEFAULT_INFLUENCE_MIN,
    max_val: float = DEFAULT_INFLUENCE_MAX,
    default: float = DEFAULT_INFLUENCE_VALUE,
) -> Tuple[float, bool]:
    """
    Parse an influence value and clamp it to a valid range.
    
    Args:
        value: Raw influence value (may be string, int, float, None, etc.)
        min_val: Minimum acceptable value (default 0.0)
        max_val: Maximum acceptable value (default 100.0)
        default: Value to use if parsing fails (default 0.0)
        
    Returns:
        Tuple of (parsed_value, was_clamped) where was_clamped indicates
        if the value exceeded bounds and was adjusted.
    """
    if value is None:
        logger.debug('Influence value is None; using default %s', default)
        return default, False
    
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        logger.warning('Unable to parse influence value %r; using default %s', value, default)
        return default, False
    
    if parsed < min_val:
        logger.warning('Influence value %s is below minimum %s; clamping to %s', parsed, min_val, min_val)
        return min_val, True
    
    if parsed > max_val:
        logger.warning('Influence value %s exceeds maximum %s; clamping to %s', parsed, max_val, max_val)
        return max_val, True
    
    return parsed, False


def parse_and_clamp_float(
    value: Any,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
    default: float = 0.0,
    field_name: str = 'value',
) -> Tuple[float, bool]:
    """
    Generic float parser with optional clamping.
    
    Args:
        value: Raw value to parse
        min_val: Minimum acceptable value (None = no minimum)
        max_val: Maximum acceptable value (None = no maximum)
        default: Default value if parsing fails
        field_name: Name of field for logging context
        
    Returns:
        Tuple of (parsed_value, was_clamped)
    """
    if value is None:
        logger.debug('%s is None; using default %s', field_name, default)
        return default, False
    
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        logger.warning('Unable to parse %s value %r; using default %s', field_name, value, default)
        return default, False
    
    clamped = False
    if min_val is not None and parsed < min_val:
        logger.warning('%s value %s is below minimum %s; clamping', field_name, parsed, min_val)
        parsed = min_val
        clamped = True
    
    if max_val is not None and parsed > max_val:
        logger.warning('%s value %s exceeds maximum %s; clamping', field_name, parsed, max_val)
        parsed = max_val
        clamped = True
    
    return parsed, clamped


def validate_influence(influence: float) -> bool:
    """
    Check if an influence value is valid (within acceptable range).
    
    Args:
        influence: The influence value to validate
        
    Returns:
        True if valid, False otherwise
    """
    return DEFAULT_INFLUENCE_MIN <= influence <= DEFAULT_INFLUENCE_MAX


def validate_score(score: float, min_val: float = 0.0, max_val: float = 1.0) -> bool:
    """
    Check if a score (e.g., trust, rivalry, betrayal_probability) is valid.
    
    Args:
        score: The score to validate
        min_val: Minimum acceptable value
        max_val: Maximum acceptable value
        
    Returns:
        True if valid, False otherwise
    """
    return min_val <= score <= max_val
