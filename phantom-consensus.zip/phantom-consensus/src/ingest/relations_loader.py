import csv
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sanitizer import sanitize_id
from cleaner import parse_and_clamp_float

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


def _normalize_text(value: Any, default: str = '') -> str:
    if value is None:
        return default
    return str(value).strip()


def _parse_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        logger.warning('Unable to parse numeric value %r; defaulting to %s.', value, default)
        return default


def _parse_trust_score(value: Any) -> float:
    parsed, was_clamped = parse_and_clamp_float(value, min_val=0.0, max_val=1.0, default=0.0, field_name='trust')
    return parsed


def _parse_rivalry_score(value: Any) -> float:
    parsed, was_clamped = parse_and_clamp_float(value, min_val=0.0, max_val=1.0, default=0.0, field_name='rivalry')
    return parsed


def _parse_betrayal_probability(value: Any) -> float:
    parsed, was_clamped = parse_and_clamp_float(value, min_val=0.0, max_val=1.0, default=0.0, field_name='betrayal_probability')
    return parsed


@dataclass(frozen=True)
class Relationship:
    representative_a_id: str
    representative_b_id: str
    trust: float
    rivalry: float
    betrayal_probability: float
    metadata: Dict[str, Any] = field(default_factory=dict, compare=False, repr=False)


def parse_relationship(row: Dict[str, str]) -> Optional[Relationship]:
    if not row:
        logger.warning('Skipping empty CSV row.')
        return None

    representative_a_id = sanitize_id(_normalize_text(row.get('rep_a') or row.get('representative_a') or row.get('representative_1') or row.get('id_a') or row.get('party_a')))
    representative_b_id = sanitize_id(_normalize_text(row.get('rep_b') or row.get('representative_b') or row.get('representative_2') or row.get('id_b') or row.get('party_b')))
    trust = _parse_trust_score(row.get('trust') or row.get('trust_score') or 0.0)
    rivalry = _parse_rivalry_score(row.get('rivalry') or row.get('rivalry_score') or 0.0)
    betrayal_probability = _parse_betrayal_probability(row.get('betrayal_probability') or row.get('betrayal') or row.get('betrayal_pct') or 0.0)

    if not representative_a_id or not representative_b_id:
        logger.warning('Skipping relationship row missing representative IDs: %r', row)
        return None

    metadata = {k: v for k, v in row.items() if k not in {
        'rep_a', 'representative_a', 'representative_1', 'id_a', 'party_a',
        'rep_b', 'representative_b', 'representative_2', 'id_b', 'party_b',
        'trust', 'trust_score', 'rivalry', 'rivalry_score',
        'betrayal_probability', 'betrayal', 'betrayal_pct'
    }}

    return Relationship(
        representative_a_id=representative_a_id,
        representative_b_id=representative_b_id,
        trust=trust,
        rivalry=rivalry,
        betrayal_probability=betrayal_probability,
        metadata=metadata,
    )


def load_relationships(filepath: str) -> List[Relationship]:
    path = Path(filepath).expanduser()
    try:
        with path.open('r', encoding='utf-8', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            relationships: List[Relationship] = []
            for row in reader:
                relationship = parse_relationship(row)
                if relationship is not None:
                    relationships.append(relationship)
    except FileNotFoundError:
        logger.error("Failed to load relationships: file '%s' not found.", filepath)
        return []
    except Exception as exc:
        logger.error("Unexpected error while loading relationships from '%s': %s", filepath, exc)
        return []

    logger.info('Loaded %d relationships from %s.', len(relationships), filepath)
    return relationships


def relationships_by_pair(relationships: List[Relationship]) -> Dict[Tuple[str, str], Relationship]:
    grouped: Dict[Tuple[str, str], Relationship] = {}
    for relationship in relationships:
        grouped[(relationship.representative_a_id, relationship.representative_b_id)] = relationship
    return grouped


def relationships_by_representative(relationships: List[Relationship]) -> Dict[str, List[Relationship]]:
    grouped: Dict[str, List[Relationship]] = {}
    for relationship in relationships:
        grouped.setdefault(relationship.representative_a_id, []).append(relationship)
        grouped.setdefault(relationship.representative_b_id, []).append(relationship)
    return grouped


if __name__ == '__main__':
    example_path = Path(__file__).parent.parent.parent / 'data' / 'relations.csv'
    relationships = load_relationships(str(example_path))
    for relationship in relationships[:20]:
        print(relationship)
