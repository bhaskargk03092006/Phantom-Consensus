"""Data ingestion module for Phantom Consensus."""

from .representatives_loader import load_representatives, index_representatives_by_id, Representative
from .proposals_loader import load_proposals, index_proposals_by_id, deduplicate_proposals, Proposal
from .objections_loader import load_objections, objections_by_proposal, objections_by_representative, Objection
from .relations_loader import load_relationships, relationships_by_pair, relationships_by_representative, Relationship
from .sanitizer import sanitize_id, sanitize_proposal_id
from .cleaner import parse_and_clamp_influence, parse_and_clamp_float
from .deduplicator import deduplicate_by_id, DeduplicationStrategy, DeduplicationReport
from .validator import validate_representatives, get_influence_statistics, DataQualityReport
from .referential_integrity import (
    validate_proposal_sponsors,
    validate_objections,
    validate_relationships,
    validate_all_references,
    ReferenceValidationStrategy,
    ReferenceValidationReport,
)

__all__ = [
    'load_representatives',
    'load_proposals',
    'load_objections',
    'load_relationships',
    'deduplicate_proposals',
    'deduplicate_by_id',
    'sanitize_id',
    'sanitize_proposal_id',
    'parse_and_clamp_influence',
    'parse_and_clamp_float',
    'validate_representatives',
    'get_influence_statistics',
    'validate_proposal_sponsors',
    'validate_objections',
    'validate_relationships',
    'validate_all_references',
    'DeduplicationStrategy',
    'DeduplicationReport',
    'DataQualityReport',
    'ReferenceValidationStrategy',
    'ReferenceValidationReport',
    'Representative',
    'Proposal',
    'Objection',
    'Relationship',
]
