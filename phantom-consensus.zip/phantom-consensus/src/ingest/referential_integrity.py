import logging
from typing import List, Dict, Set, Tuple, Optional
from enum import Enum

logger = logging.getLogger(__name__)


class ReferenceValidationStrategy(Enum):
    """Strategy for handling records with missing references."""
    REMOVE = "remove"        # Remove records with invalid references
    WARN = "warn"           # Log warning but keep records
    ERROR = "error"         # Log error but keep records


class ReferenceValidationReport:
    """Tracks reference validation issues across datasets."""
    
    def __init__(self):
        self.total_records = 0
        self.valid_records = 0
        self.invalid_records = 0
        self.orphaned_by_type: Dict[str, List[str]] = {}  # Maps record type to list of orphaned IDs
        self.missing_refs: Dict[str, Set[str]] = {}       # Maps ref type to missing IDs
        self.issues: List[str] = []
    
    def add_issue(self, issue: str, log_level: str = 'warning'):
        self.issues.append(issue)
        if log_level == 'warning':
            logger.warning(issue)
        elif log_level == 'error':
            logger.error(issue)
        else:
            logger.debug(issue)
    
    def report(self):
        """Print a summary of validation findings."""
        print("\n=== Reference Validation Report ===")
        print(f"Total records checked: {self.total_records}")
        print(f"Valid references: {self.valid_records}")
        print(f"Invalid references: {self.invalid_records}")
        
        if self.missing_refs:
            print(f"\nMissing entity references:")
            for ref_type, missing_ids in self.missing_refs.items():
                print(f"  {ref_type}: {len(missing_ids)} missing")
                for missing_id in sorted(missing_ids)[:5]:
                    print(f"    - '{missing_id}'")
                if len(missing_ids) > 5:
                    print(f"    ... and {len(missing_ids) - 5} more")
        
        if self.orphaned_by_type:
            print(f"\nOrphaned records by type:")
            for record_type, orphaned_ids in self.orphaned_by_type.items():
                print(f"  {record_type}: {len(orphaned_ids)} orphaned")
                for orphaned_id in orphaned_ids[:5]:
                    print(f"    - {orphaned_id}")
                if len(orphaned_ids) > 5:
                    print(f"    ... and {len(orphaned_ids) - 5} more")
        
        if self.issues:
            print(f"\nTotal issues detected: {len(self.issues)}")
            for issue in self.issues[:10]:
                print(f"  - {issue}")
            if len(self.issues) > 10:
                print(f"  ... and {len(self.issues) - 10} more")


def validate_proposal_sponsors(
    proposals: List,
    valid_representative_ids: Set[str],
    strategy: ReferenceValidationStrategy = ReferenceValidationStrategy.WARN,
) -> Tuple[List, ReferenceValidationReport]:
    """
    Validate that all proposals are sponsored by valid representatives.
    
    Args:
        proposals: List of Proposal objects
        valid_representative_ids: Set of valid representative IDs
        strategy: How to handle proposals with missing sponsors
        
    Returns:
        Tuple of (filtered_proposals, validation_report)
    """
    report = ReferenceValidationReport()
    report.total_records = len(proposals)
    
    filtered = []
    for proposal in proposals:
        if proposal.sponsor_id not in valid_representative_ids:
            report.invalid_records += 1
            if 'proposals' not in report.orphaned_by_type:
                report.orphaned_by_type['proposals'] = []
            if 'representative' not in report.missing_refs:
                report.missing_refs['representative'] = set()
            
            report.orphaned_by_type['proposals'].append(proposal.id)
            report.missing_refs['representative'].add(proposal.sponsor_id)
            report.add_issue(
                f"Proposal '{proposal.id}' references missing sponsor '{proposal.sponsor_id}'",
                log_level='warning'
            )
            
            if strategy == ReferenceValidationStrategy.REMOVE:
                continue
        
        filtered.append(proposal)
        report.valid_records += 1
    
    return filtered, report


def validate_objections(
    objections: List,
    valid_representative_ids: Set[str],
    valid_proposal_ids: Set[str],
    strategy: ReferenceValidationStrategy = ReferenceValidationStrategy.WARN,
) -> Tuple[List, ReferenceValidationReport]:
    """
    Validate that all objections reference valid representatives and proposals.
    
    Args:
        objections: List of Objection objects
        valid_representative_ids: Set of valid representative IDs
        valid_proposal_ids: Set of valid proposal IDs
        strategy: How to handle objections with missing references
        
    Returns:
        Tuple of (filtered_objections, validation_report)
    """
    report = ReferenceValidationReport()
    report.total_records = len(objections)
    
    filtered = []
    for objection in objections:
        is_valid = True
        issues = []
        
        if objection.representative_id not in valid_representative_ids:
            is_valid = False
            if 'representative' not in report.missing_refs:
                report.missing_refs['representative'] = set()
            report.missing_refs['representative'].add(objection.representative_id)
            issues.append(f"missing representative '{objection.representative_id}'")
        
        if objection.proposal_id not in valid_proposal_ids:
            is_valid = False
            if 'proposal' not in report.missing_refs:
                report.missing_refs['proposal'] = set()
            report.missing_refs['proposal'].add(objection.proposal_id)
            issues.append(f"missing proposal '{objection.proposal_id}'")
        
        if not is_valid:
            report.invalid_records += 1
            if 'objections' not in report.orphaned_by_type:
                report.orphaned_by_type['objections'] = []
            report.orphaned_by_type['objections'].append(
                f"{objection.proposal_id}:{objection.representative_id}"
            )
            
            issue_str = ', '.join(issues)
            report.add_issue(
                f"Objection ({issue_str})",
                log_level='warning'
            )
            
            if strategy == ReferenceValidationStrategy.REMOVE:
                continue
        
        filtered.append(objection)
        report.valid_records += 1
    
    return filtered, report


def validate_relationships(
    relationships: List,
    valid_representative_ids: Set[str],
    strategy: ReferenceValidationStrategy = ReferenceValidationStrategy.WARN,
) -> Tuple[List, ReferenceValidationReport]:
    """
    Validate that all relationships reference valid representatives.
    
    Args:
        relationships: List of Relationship objects
        valid_representative_ids: Set of valid representative IDs
        strategy: How to handle relationships with missing references
        
    Returns:
        Tuple of (filtered_relationships, validation_report)
    """
    report = ReferenceValidationReport()
    report.total_records = len(relationships)
    
    filtered = []
    for relationship in relationships:
        is_valid = True
        missing = []
        
        if relationship.representative_a_id not in valid_representative_ids:
            is_valid = False
            if 'representative' not in report.missing_refs:
                report.missing_refs['representative'] = set()
            report.missing_refs['representative'].add(relationship.representative_a_id)
            missing.append(f"'{relationship.representative_a_id}'")
        
        if relationship.representative_b_id not in valid_representative_ids:
            is_valid = False
            if 'representative' not in report.missing_refs:
                report.missing_refs['representative'] = set()
            report.missing_refs['representative'].add(relationship.representative_b_id)
            missing.append(f"'{relationship.representative_b_id}'")
        
        if not is_valid:
            report.invalid_records += 1
            if 'relationships' not in report.orphaned_by_type:
                report.orphaned_by_type['relationships'] = []
            report.orphaned_by_type['relationships'].append(
                f"{relationship.representative_a_id}↔{relationship.representative_b_id}"
            )
            
            missing_str = ', '.join(missing)
            report.add_issue(
                f"Relationship has missing representatives: {missing_str}",
                log_level='warning'
            )
            
            if strategy == ReferenceValidationStrategy.REMOVE:
                continue
        
        filtered.append(relationship)
        report.valid_records += 1
    
    return filtered, report


def validate_all_references(
    representatives: List,
    proposals: List,
    objections: List,
    relationships: List,
    strategy: ReferenceValidationStrategy = ReferenceValidationStrategy.WARN,
) -> Tuple[Dict, ReferenceValidationReport]:
    """
    Comprehensive validation of all cross-dataset references.
    
    Args:
        representatives: List of Representative objects
        proposals: List of Proposal objects
        objections: List of Objection objects
        relationships: List of Relationship objects
        strategy: How to handle records with missing references
        
    Returns:
        Tuple of (
            {
                'representatives': filtered_representatives,
                'proposals': filtered_proposals,
                'objections': filtered_objections,
                'relationships': filtered_relationships,
            },
            combined_validation_report
        )
    """
    # Build sets of valid IDs
    valid_representative_ids = {rep.id for rep in representatives}
    valid_proposal_ids = {proposal.id for proposal in proposals}
    
    # Validate each dataset
    validated_proposals, proposal_report = validate_proposal_sponsors(
        proposals, valid_representative_ids, strategy
    )
    
    # Update valid proposal IDs after filtering
    if strategy == ReferenceValidationStrategy.REMOVE:
        valid_proposal_ids = {p.id for p in validated_proposals}
    
    validated_objections, objection_report = validate_objections(
        objections, valid_representative_ids, valid_proposal_ids, strategy
    )
    
    validated_relationships, relationship_report = validate_relationships(
        relationships, valid_representative_ids, strategy
    )
    
    # Combine reports
    combined_report = ReferenceValidationReport()
    combined_report.total_records = (
        proposal_report.total_records +
        objection_report.total_records +
        relationship_report.total_records
    )
    combined_report.valid_records = (
        proposal_report.valid_records +
        objection_report.valid_records +
        relationship_report.valid_records
    )
    combined_report.invalid_records = (
        proposal_report.invalid_records +
        objection_report.invalid_records +
        relationship_report.invalid_records
    )
    
    for record_type, ids in proposal_report.orphaned_by_type.items():
        combined_report.orphaned_by_type.setdefault(record_type, []).extend(ids)
    for record_type, ids in objection_report.orphaned_by_type.items():
        combined_report.orphaned_by_type.setdefault(record_type, []).extend(ids)
    for record_type, ids in relationship_report.orphaned_by_type.items():
        combined_report.orphaned_by_type.setdefault(record_type, []).extend(ids)
    
    for ref_type, ids in proposal_report.missing_refs.items():
        combined_report.missing_refs.setdefault(ref_type, set()).update(ids)
    for ref_type, ids in objection_report.missing_refs.items():
        combined_report.missing_refs.setdefault(ref_type, set()).update(ids)
    for ref_type, ids in relationship_report.missing_refs.items():
        combined_report.missing_refs.setdefault(ref_type, set()).update(ids)
    
    combined_report.issues.extend(proposal_report.issues)
    combined_report.issues.extend(objection_report.issues)
    combined_report.issues.extend(relationship_report.issues)
    
    logger.info(
        'Reference validation complete: %d valid, %d invalid records',
        combined_report.valid_records, combined_report.invalid_records
    )
    
    return {
        'representatives': representatives,
        'proposals': validated_proposals,
        'objections': validated_objections,
        'relationships': validated_relationships,
    }, combined_report
