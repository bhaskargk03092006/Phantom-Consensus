import logging
from typing import List, Dict, Optional, Callable, TypeVar
from enum import Enum

logger = logging.getLogger(__name__)

T = TypeVar('T')


class DeduplicationStrategy(Enum):
    """Strategy for selecting which duplicate to keep."""
    FIRST = "first"          # Keep the first occurrence
    LAST = "last"            # Keep the last occurrence
    HIGHEST_PRIORITY = "highest_priority"  # Keep the one with highest priority (proposals)
    LOWEST_SEVERITY = "lowest_severity"    # Keep the one with lowest severity (objections)


class DeduplicationReport:
    """Tracks deduplication actions and statistics."""
    
    def __init__(self):
        self.total_records = 0
        self.duplicates_found = 0
        self.duplicates_removed = 0
        self.unique_records = 0
        self.duplicate_groups: Dict[str, int] = {}  # Maps ID to count of duplicates
        self.actions: List[str] = []
    
    def add_action(self, action: str):
        self.actions.append(action)
        logger.debug(action)
    
    def report(self):
        """Print a summary of deduplication findings."""
        print("\n=== Deduplication Report ===")
        print(f"Total records processed: {self.total_records}")
        print(f"Unique records kept: {self.unique_records}")
        print(f"Duplicate groups found: {self.duplicates_found}")
        print(f"Duplicate records removed: {self.duplicates_removed}")
        
        if self.duplicate_groups:
            print(f"\nDuplicate distribution:")
            for duplicate_id, count in sorted(self.duplicate_groups.items())[:10]:
                print(f"  ID '{duplicate_id}': {count} occurrences")
            if len(self.duplicate_groups) > 10:
                print(f"  ... and {len(self.duplicate_groups) - 10} more")
        
        if self.actions:
            print(f"\nDeduplication actions (first 10):")
            for action in self.actions[:10]:
                print(f"  - {action}")
            if len(self.actions) > 10:
                print(f"  ... and {len(self.actions) - 10} more")


def deduplicate_by_id(
    items: List[T],
    id_getter: Callable[[T], str],
    strategy: DeduplicationStrategy = DeduplicationStrategy.FIRST,
    priority_getter: Optional[Callable[[T], float]] = None,
) -> List[T]:
    """
    Deduplicate a list of items based on a unique identifier.
    
    Args:
        items: List of items to deduplicate
        id_getter: Function to extract the unique ID from an item
        strategy: Strategy for selecting which duplicate to keep
        priority_getter: Function to extract priority (required for HIGHEST_PRIORITY strategy)
        
    Returns:
        List of deduplicated items
    """
    if not items:
        return []
    
    report = DeduplicationReport()
    report.total_records = len(items)
    
    # Group items by ID
    groups: Dict[str, List[T]] = {}
    for item in items:
        item_id = id_getter(item)
        if item_id not in groups:
            groups[item_id] = []
        groups[item_id].append(item)
    
    # Select representative from each group
    result: List[T] = []
    for item_id, group in groups.items():
        if len(group) == 1:
            result.append(group[0])
            report.unique_records += 1
        else:
            report.duplicates_found += 1
            report.duplicate_groups[item_id] = len(group)
            report.duplicates_removed += len(group) - 1
            
            # Apply deduplication strategy
            if strategy == DeduplicationStrategy.FIRST:
                selected = group[0]
                report.add_action(f"ID '{item_id}': keeping first of {len(group)} duplicates")
            elif strategy == DeduplicationStrategy.LAST:
                selected = group[-1]
                report.add_action(f"ID '{item_id}': keeping last of {len(group)} duplicates")
            elif strategy == DeduplicationStrategy.HIGHEST_PRIORITY:
                if priority_getter is None:
                    raise ValueError("priority_getter required for HIGHEST_PRIORITY strategy")
                selected = max(group, key=priority_getter)
                selected_priority = priority_getter(selected)
                report.add_action(f"ID '{item_id}': keeping highest priority ({selected_priority}) of {len(group)} duplicates")
            elif strategy == DeduplicationStrategy.LOWEST_SEVERITY:
                if priority_getter is None:
                    raise ValueError("priority_getter required for LOWEST_SEVERITY strategy")
                selected = min(group, key=priority_getter)
                selected_severity = priority_getter(selected)
                report.add_action(f"ID '{item_id}': keeping lowest severity ({selected_severity}) of {len(group)} duplicates")
            else:
                selected = group[0]
                report.add_action(f"ID '{item_id}': keeping first of {len(group)} duplicates (unknown strategy)")
            
            result.append(selected)
    
    logger.info(
        'Deduplication complete: %d unique records from %d total (removed %d duplicates)',
        len(result), report.total_records, report.duplicates_removed
    )
    
    return result


def find_duplicate_ids(items: List[T], id_getter: Callable[[T], str]) -> Dict[str, int]:
    """
    Identify which IDs have duplicates.
    
    Args:
        items: List of items to check
        id_getter: Function to extract the unique ID
        
    Returns:
        Dictionary mapping duplicate IDs to their occurrence counts
    """
    id_counts: Dict[str, int] = {}
    for item in items:
        item_id = id_getter(item)
        id_counts[item_id] = id_counts.get(item_id, 0) + 1
    
    # Return only IDs with duplicates
    return {item_id: count for item_id, count in id_counts.items() if count > 1}
