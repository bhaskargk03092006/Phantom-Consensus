import logging
from typing import List, Dict, Tuple
from representatives_loader import Representative

logger = logging.getLogger(__name__)


class DataQualityReport:
    """Tracks data quality issues during ingestion and cleaning."""
    
    def __init__(self):
        self.total_records = 0
        self.valid_records = 0
        self.skipped_records = 0
        self.clamped_values: Dict[str, int] = {}
        self.null_values: Dict[str, int] = {}
        self.out_of_range_count = 0
        self.issues: List[str] = []
    
    def add_issue(self, issue: str):
        self.issues.append(issue)
        logger.warning(issue)
    
    def report(self):
        """Print a summary of data quality findings."""
        print("\n=== Data Quality Report ===")
        print(f"Total records: {self.total_records}")
        print(f"Valid records: {self.valid_records}")
        print(f"Skipped records: {self.skipped_records}")
        
        if self.clamped_values:
            print(f"\nClamped values by field:")
            for field, count in self.clamped_values.items():
                print(f"  {field}: {count}")
        
        if self.out_of_range_count > 0:
            print(f"\nOut-of-range values: {self.out_of_range_count}")
        
        if self.issues:
            print(f"\nTotal issues detected: {len(self.issues)}")
            for issue in self.issues[:10]:  # Show first 10
                print(f"  - {issue}")
            if len(self.issues) > 10:
                print(f"  ... and {len(self.issues) - 10} more")


def validate_representatives(representatives: List[Representative], strict: bool = False) -> Tuple[List[Representative], DataQualityReport]:
    """
    Validate representatives for data quality issues.
    
    Args:
        representatives: List of loaded representative records
        strict: If True, filter out any record with invalid influence. If False, keep all records.
        
    Returns:
        Tuple of (filtered_representatives, quality_report)
    """
    report = DataQualityReport()
    report.total_records = len(representatives)
    
    filtered = []
    for rep in representatives:
        if rep.influence < 0.0 or rep.influence > 100.0:
            report.out_of_range_count += 1
            report.add_issue(f"Representative {rep.id} ({rep.name}) has out-of-range influence: {rep.influence}")
            if strict:
                report.skipped_records += 1
                continue
        
        filtered.append(rep)
        report.valid_records += 1
    
    if not strict:
        report.skipped_records = 0
    
    return filtered, report


def get_influence_statistics(representatives: List[Representative]) -> Dict[str, float]:
    """Calculate influence statistics."""
    if not representatives:
        return {
            'min': 0.0,
            'max': 0.0,
            'avg': 0.0,
            'median': 0.0,
            'count': 0,
        }
    
    influences = sorted([rep.influence for rep in representatives])
    total = sum(influences)
    count = len(influences)
    
    return {
        'min': influences[0],
        'max': influences[-1],
        'avg': total / count,
        'median': influences[count // 2],
        'count': count,
    }
