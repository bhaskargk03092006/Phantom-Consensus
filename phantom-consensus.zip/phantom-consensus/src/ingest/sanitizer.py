import logging
from typing import List, Dict, Set

logger = logging.getLogger(__name__)


def sanitize_id(raw_id: str) -> str:
    """
    Normalize a representative ID by:
    - Stripping leading/trailing whitespace
    - Converting to uppercase
    - Removing internal extra whitespace
    
    Args:
        raw_id: The raw ID string
        
    Returns:
        Normalized ID string
    """
    if not raw_id:
        return ""
    normalized = str(raw_id).strip().upper()
    # Collapse multiple spaces to single space
    normalized = " ".join(normalized.split())
    return normalized


def sanitize_proposal_id(raw_id: str) -> str:
    """Normalize a proposal ID."""
    return sanitize_id(raw_id)


def validate_id_consistency(ids: List[str], context: str = "IDs") -> Dict[str, int]:
    """
    Analyze ID consistency before and after sanitization.
    Logs warnings for IDs that differ only in case or whitespace.
    
    Args:
        ids: List of raw IDs
        context: Context string for logging
        
    Returns:
        Dictionary mapping sanitized IDs to frequency
    """
    if not ids:
        return {}
    
    sanitized_counts: Dict[str, int] = {}
    raw_to_sanitized: Dict[str, str] = {}
    
    for raw_id in ids:
        sanitized = sanitize_id(raw_id)
        sanitized_counts[sanitized] = sanitized_counts.get(sanitized, 0) + 1
        
        if raw_id in raw_to_sanitized:
            if raw_to_sanitized[raw_id] != sanitized:
                logger.warning(
                    "Inconsistent sanitization for '%s': expected '%s', got '%s'",
                    raw_id, raw_to_sanitized[raw_id], sanitized
                )
        else:
            raw_to_sanitized[raw_id] = sanitized
            
            # Check if this raw ID normalizes differently than other variants
            for other_raw, other_sanitized in raw_to_sanitized.items():
                if other_raw != raw_id and other_sanitized == sanitized:
                    logger.debug(
                        "Multiple formatting variants map to '%s': '%s' and '%s'",
                        sanitized, other_raw, raw_id
                    )
    
    return sanitized_counts


def get_id_mapping(raw_ids: List[str]) -> Dict[str, str]:
    """
    Create a mapping from raw IDs to sanitized IDs.
    
    Args:
        raw_ids: List of raw IDs
        
    Returns:
        Dictionary mapping raw IDs to sanitized versions
    """
    return {raw_id: sanitize_id(raw_id) for raw_id in raw_ids if raw_id}
