import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from sanitizer import sanitize_id, sanitize_proposal_id
from cleaner import parse_and_clamp_float

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Objection:
    proposal_id: str
    representative_id: str
    severity: float
    metadata: Dict[str, Any] = field(default_factory=dict, compare=False, repr=False)


def _normalize_text(value: Any, default: str = '') -> str:
    if value is None:
        return default
    return str(value).strip()


def _parse_severity(value: Any) -> float:
    parsed, was_clamped = parse_and_clamp_float(value, min_val=0.0, max_val=100.0, default=0.0, field_name='severity')
    return parsed


def parse_objection(record: Dict[str, Any]) -> Optional[Objection]:
    if not isinstance(record, dict):
        logger.warning('Skipping objection record that is not a JSON object: %r', record)
        return None

    proposal_id = sanitize_proposal_id(_normalize_text(record.get('proposal_id') or record.get('proposal') or record.get('bill_id')))
    representative_id = sanitize_id(_normalize_text(record.get('representative_id') or record.get('rep_id') or record.get('objector_id')))
    severity = _parse_severity(record.get('severity') or record.get('severity_score') or 0.0)

    if not proposal_id or not representative_id:
        logger.warning('Skipping invalid objection record without proposal_id or representative_id: %r', record)
        return None

    metadata = {
        key: value
        for key, value in record.items()
        if key not in {'proposal_id', 'proposal', 'bill_id', 'representative_id', 'rep_id', 'objector_id', 'severity', 'severity_score'}
    }

    return Objection(
        proposal_id=proposal_id,
        representative_id=representative_id,
        severity=severity,
        metadata=metadata,
    )


def load_objections(filepath: str) -> List[Objection]:
    path = Path(filepath).expanduser()
    try:
        with path.open('r', encoding='utf-8') as file:
            raw = json.load(file)
    except FileNotFoundError:
        logger.error("Failed to load objections: file '%s' not found.", filepath)
        return []
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse JSON in '%s'. Error: %s", filepath, exc)
        return []
    except Exception as exc:
        logger.error("Unexpected error while loading objections from '%s': %s", filepath, exc)
        return []

    if isinstance(raw, dict):
        raw = raw.get('objections', raw.get('data', raw))

    if not isinstance(raw, list):
        logger.error("Expected JSON array or object with an 'objections' key in '%s'.", filepath)
        return []

    objections: List[Objection] = []
    for item in raw:
        objection = parse_objection(item)
        if objection is not None:
            objections.append(objection)

    logger.info('Loaded %d objections from %s.', len(objections), filepath)
    return objections


def objections_by_proposal(objections: List[Objection]) -> Dict[str, List[Objection]]:
    grouped: Dict[str, List[Objection]] = {}
    for objection in objections:
        grouped.setdefault(objection.proposal_id, []).append(objection)
    return grouped


def objections_by_representative(objections: List[Objection]) -> Dict[str, List[Objection]]:
    grouped: Dict[str, List[Objection]] = {}
    for objection in objections:
        grouped.setdefault(objection.representative_id, []).append(objection)
    return grouped


if __name__ == '__main__':
    example_path = Path(__file__).parent.parent.parent / 'data' / 'objections.json'
    objections = load_objections(str(example_path))
    for objection in objections[:20]:
        print(objection)
