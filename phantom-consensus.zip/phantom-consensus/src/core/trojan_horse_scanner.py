import logging
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class RiskLevel(Enum):
    """Classification of representative reliability risk."""
    SAFE = "safe"                      # Low influence or low betrayal risk
    MODERATE_RISK = "moderate_risk"    # Medium-high influence with acceptable betrayal
    HIGH_RISK = "high_risk"            # High influence with high betrayal (TROJAN HORSE)
    CRITICAL_RISK = "critical_risk"    # Extremely risky (very high influence + very high betrayal)


@dataclass(frozen=True)
class RiskAssessment:
    """Risk assessment for a representative."""
    representative_id: str
    name: str
    influence: float
    betrayal_probability: float
    risk_level: RiskLevel
    risk_score: float  # Composite risk metric
    reason: str  # Explanation of risk classification


def compute_risk_score(
    influence: float,
    betrayal_probability: float,
) -> float:
    """
    Compute a composite risk score for a representative.
    
    Risk increases with both influence (more damage when they betray)
    and betrayal probability (higher likelihood).
    
    Formula: risk_score = (influence / 100) * betrayal_probability
    
    Args:
        influence: Influence score (0-100)
        betrayal_probability: Probability of betrayal (0-1)
        
    Returns:
        Risk score (0-1), where higher = more risky
    """
    inf_norm = min(1.0, max(0.0, influence / 100.0))
    betrayal_norm = min(1.0, max(0.0, betrayal_probability))
    
    risk = inf_norm * betrayal_norm
    return min(1.0, risk)


def classify_risk_level(
    influence: float,
    betrayal_probability: float,
    influence_threshold: float = 60.0,
    betrayal_threshold: float = 0.6,
    critical_betrayal_threshold: float = 0.8,
) -> Tuple[RiskLevel, str]:
    """
    Classify a representative's risk level based on influence and betrayal probability.
    
    Args:
        influence: Influence score (0-100)
        betrayal_probability: Probability of betrayal (0-1)
        influence_threshold: Influence score above which risk escalates (default 60)
        betrayal_threshold: Betrayal probability above which risk escalates (default 0.6)
        critical_betrayal_threshold: Very high betrayal probability (default 0.8)
        
    Returns:
        Tuple of (RiskLevel, explanation_string)
    """
    high_influence = influence >= influence_threshold
    moderate_betrayal = betrayal_probability >= betrayal_threshold
    critical_betrayal = betrayal_probability >= critical_betrayal_threshold
    
    if critical_betrayal and high_influence:
        return RiskLevel.CRITICAL_RISK, \
            f"Extremely high betrayal probability ({betrayal_probability:.1%}) with substantial influence"
    
    if high_influence and moderate_betrayal:
        return RiskLevel.HIGH_RISK, \
            f"High influence ({influence:.0f}) combined with high betrayal risk ({betrayal_probability:.1%})"
    
    if high_influence:
        return RiskLevel.MODERATE_RISK, \
            f"High influence ({influence:.0f}) but acceptable betrayal risk ({betrayal_probability:.1%})"
    
    return RiskLevel.SAFE, \
        f"Low risk: influence={influence:.0f}, betrayal={betrayal_probability:.1%}"


def assess_representatives(
    representatives: List,
    influence_threshold: float = 60.0,
    betrayal_threshold: float = 0.6,
) -> List[RiskAssessment]:
    """
    Perform risk assessment on all representatives.
    
    Args:
        representatives: List of Representative objects
        influence_threshold: Influence score threshold for escalated risk
        betrayal_threshold: Betrayal probability threshold for escalated risk
        
    Returns:
        List of RiskAssessment objects
    """
    assessments = []
    
    for rep in representatives:
        risk_score = compute_risk_score(rep.influence, rep.betrayal_probability)
        risk_level, reason = classify_risk_level(
            rep.influence,
            rep.betrayal_probability,
            influence_threshold,
            betrayal_threshold,
        )
        
        assessment = RiskAssessment(
            representative_id=rep.id,
            name=rep.name,
            influence=rep.influence,
            betrayal_probability=rep.betrayal_probability,
            risk_level=risk_level,
            risk_score=risk_score,
            reason=reason,
        )
        assessments.append(assessment)
    
    logger.info('Completed risk assessment for %d representatives', len(assessments))
    return assessments


def filter_trojan_horses(
    representatives: List,
    assessments: List[RiskAssessment],
    allowed_risk_level: RiskLevel = RiskLevel.HIGH_RISK,
) -> Tuple[List, List[RiskAssessment]]:
    """
    Filter out representatives above a specified risk threshold.
    
    Args:
        representatives: Original list of Representative objects
        assessments: RiskAssessment objects for each representative
        allowed_risk_level: Maximum acceptable risk level:
            - RiskLevel.SAFE: only safe reps
            - RiskLevel.MODERATE_RISK: safe + moderate
            - RiskLevel.HIGH_RISK: safe + moderate (default, excludes HIGH_RISK and CRITICAL)
            - RiskLevel.CRITICAL_RISK: all (no filtering)
        
    Returns:
        Tuple of (filtered_representatives, filtered_out_assessments)
    """
    # Define which risk levels are acceptable
    acceptable_levels = []
    if allowed_risk_level == RiskLevel.SAFE:
        acceptable_levels = [RiskLevel.SAFE]
    elif allowed_risk_level == RiskLevel.MODERATE_RISK:
        acceptable_levels = [RiskLevel.SAFE, RiskLevel.MODERATE_RISK]
    elif allowed_risk_level == RiskLevel.HIGH_RISK:
        acceptable_levels = [RiskLevel.SAFE, RiskLevel.MODERATE_RISK]  # Exclude HIGH and CRITICAL
    elif allowed_risk_level == RiskLevel.CRITICAL_RISK:
        acceptable_levels = [RiskLevel.SAFE, RiskLevel.MODERATE_RISK, RiskLevel.HIGH_RISK, RiskLevel.CRITICAL_RISK]
    
    # Create mapping of rep ID to assessment
    assessment_by_id = {a.representative_id: a for a in assessments}
    
    # Filter representatives
    filtered_reps = []
    filtered_out = []
    
    for rep in representatives:
        assessment = assessment_by_id.get(rep.id)
        if assessment is None:
            logger.warning('No risk assessment found for %s; excluding', rep.id)
            filtered_out.append(None)
            continue
        
        if assessment.risk_level in acceptable_levels:
            filtered_reps.append(rep)
        else:
            filtered_out.append(assessment)
            logger.warning(
                'Filtering out TROJAN HORSE: %s (%s) - %s',
                rep.id, assessment.name, assessment.reason
            )
    
    logger.info(
        'Filtered %d Trojan Horse representatives from %d total',
        len([a for a in filtered_out if a is not None]),
        len(representatives)
    )
    
    return filtered_reps, [a for a in filtered_out if a is not None]


def identify_trojan_horses(
    assessments: List[RiskAssessment],
) -> List[RiskAssessment]:
    """
    Identify all HIGH_RISK and CRITICAL_RISK representatives.
    
    Args:
        assessments: List of RiskAssessment objects
        
    Returns:
        List of risky assessments (HIGH_RISK and CRITICAL_RISK only)
    """
    trojan_horses = [
        a for a in assessments
        if a.risk_level in [RiskLevel.HIGH_RISK, RiskLevel.CRITICAL_RISK]
    ]
    
    logger.info('Identified %d Trojan Horse representatives', len(trojan_horses))
    return trojan_horses


def get_risk_summary(
    assessments: List[RiskAssessment],
) -> Dict[RiskLevel, int]:
    """
    Get count of representatives in each risk level.
    
    Args:
        assessments: List of RiskAssessment objects
        
    Returns:
        Dictionary mapping RiskLevel to count
    """
    summary = {level: 0 for level in RiskLevel}
    
    for assessment in assessments:
        summary[assessment.risk_level] += 1
    
    return summary


@dataclass(frozen=True)
class TrojanHorseReport:
    """Summary report of Trojan Horse filtering."""
    total_representatives: int
    safe_count: int
    moderate_risk_count: int
    high_risk_count: int
    critical_risk_count: int
    trojan_horses_filtered: int
    representatives_remaining: int
    filtered_influence_total: float  # Sum of influence from filtered reps


def generate_trojan_horse_report(
    original_representatives: List,
    filtered_representatives: List,
    filtered_out_assessments: List[RiskAssessment],
    risk_summary: Dict[RiskLevel, int],
) -> TrojanHorseReport:
    """
    Generate a comprehensive Trojan Horse filtering report.
    
    Args:
        original_representatives: Original representative list
        filtered_representatives: Representatives after filtering
        filtered_out_assessments: Risk assessments of filtered-out reps
        risk_summary: Result from get_risk_summary()
        
    Returns:
        TrojanHorseReport with statistics
    """
    filtered_influence = sum(a.influence for a in filtered_out_assessments)
    
    return TrojanHorseReport(
        total_representatives=len(original_representatives),
        safe_count=risk_summary[RiskLevel.SAFE],
        moderate_risk_count=risk_summary[RiskLevel.MODERATE_RISK],
        high_risk_count=risk_summary[RiskLevel.HIGH_RISK],
        critical_risk_count=risk_summary[RiskLevel.CRITICAL_RISK],
        trojan_horses_filtered=len(filtered_out_assessments),
        representatives_remaining=len(filtered_representatives),
        filtered_influence_total=filtered_influence,
    )


def print_trojan_horse_report(report: TrojanHorseReport):
    """Print a formatted Trojan Horse filtering report."""
    print("\n=== Trojan Horse Filtering Report ===")
    print(f"Total representatives: {report.total_representatives}")
    print(f"\nRisk distribution:")
    print(f"  SAFE:            {report.safe_count}")
    print(f"  MODERATE_RISK:   {report.moderate_risk_count}")
    print(f"  HIGH_RISK:       {report.high_risk_count}")
    print(f"  CRITICAL_RISK:   {report.critical_risk_count}")
    print(f"\nFiltering results:")
    print(f"  Trojan Horses filtered:    {report.trojan_horses_filtered}")
    print(f"  Representatives remaining: {report.representatives_remaining}")
    print(f"  Influence removed:         {report.filtered_influence_total:.0f}")


def get_high_influence_high_betrayal(
    assessments: List[RiskAssessment],
    min_influence: float = 70.0,
    min_betrayal: float = 0.5,
) -> List[RiskAssessment]:
    """
    Get representatives with both high influence AND high betrayal (potential Trojan Horses).
    
    Args:
        assessments: List of RiskAssessment objects
        min_influence: Minimum influence threshold (default 70)
        min_betrayal: Minimum betrayal probability (default 0.5)
        
    Returns:
        List of RiskAssessment objects matching criteria
    """
    candidates = [
        a for a in assessments
        if a.influence >= min_influence and a.betrayal_probability >= min_betrayal
    ]
    
    return candidates
