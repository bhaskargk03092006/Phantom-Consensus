import logging
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class ProposalViability(Enum):
    """Classification of proposal viability based on priority vs. objections."""
    VIABLE = "viable"                  # High priority, acceptable objections
    AT_RISK = "at_risk"               # Moderate priority with significant objections
    POISON_PILL = "poison_pill"       # High priority overwhelmed by objections
    UNCONTESTED = "uncontested"       # Low or no objections regardless of priority


@dataclass(frozen=True)
class ProposalViabilityAssessment:
    """Viability assessment for a proposal."""
    proposal_id: str
    title: str
    priority: float
    objection_weight: float
    viability: ProposalViability
    viability_score: float  # 0-1: higher = more viable
    is_poison_pill: bool
    reason: str


def compute_viability_score(
    priority: float,
    objection_weight: float,
    priority_weight: float = 1.0,
    objection_weight_factor: float = 1.0,
) -> float:
    """
    Compute a proposal viability score balancing priority against objections.
    
    Formula: viability = (priority / 100) * (1 - objection_weight)
    
    This ensures:
    - High priority with low objections = high viability
    - High priority with high objections = low viability (objections override)
    - Low priority = low viability regardless of objections
    
    Args:
        priority: Proposal priority (0-100)
        objection_weight: Aggregate objection weight (0-1)
        priority_weight: Weight for priority component (default 1.0)
        objection_weight_factor: Weight for objection penalty (default 1.0)
        
    Returns:
        Viability score (0-1)
    """
    priority_norm = min(1.0, max(0.0, priority / 100.0))
    objection_norm = min(1.0, max(0.0, objection_weight))
    
    viability = priority_norm * (1.0 - objection_norm)
    return min(1.0, max(0.0, viability))


def classify_viability(
    priority: float,
    objection_weight: float,
    viability_score: float,
    priority_threshold: float = 70.0,
    poison_pill_threshold: float = 0.3,
    at_risk_threshold: float = 0.5,
) -> Tuple[ProposalViability, str]:
    """
    Classify proposal viability based on priority, objections, and computed score.
    
    Args:
        priority: Proposal priority (0-100)
        objection_weight: Aggregate objection weight (0-1)
        viability_score: Computed viability score (from compute_viability_score)
        priority_threshold: Priority above which proposal is considered important (default 70)
        poison_pill_threshold: Viability below which proposal is poison pill (default 0.3)
        at_risk_threshold: Viability below which proposal is at-risk (default 0.5)
        
    Returns:
        Tuple of (ProposalViability, explanation_string)
    """
    high_priority = priority >= priority_threshold
    high_objections = objection_weight >= 0.6
    
    if viability_score < poison_pill_threshold and high_priority:
        return ProposalViability.POISON_PILL, \
            f"High priority ({priority:.0f}) but viability severely compromised by objections (weight={objection_weight:.2f})"
    
    if viability_score < at_risk_threshold:
        return ProposalViability.AT_RISK, \
            f"Objection weight ({objection_weight:.2f}) threatens proposal viability (score={viability_score:.2f})"
    
    if objection_weight < 0.1:
        return ProposalViability.UNCONTESTED, \
            f"Minimal objections received (weight={objection_weight:.2f})"
    
    return ProposalViability.VIABLE, \
        f"Acceptable balance between priority ({priority:.0f}) and objections ({objection_weight:.2f})"


def assess_proposal_viability(
    proposals: List,
    objection_profiles: Dict,
    priority_threshold: float = 70.0,
    poison_pill_threshold: float = 0.3,
) -> List[ProposalViabilityAssessment]:
    """
    Perform viability assessment on all proposals.
    
    Args:
        proposals: List of Proposal objects
        objection_profiles: Dictionary from aggregate_objection_weights()
        priority_threshold: Priority threshold for high-priority classification
        poison_pill_threshold: Viability threshold for poison pill detection
        
    Returns:
        List of ProposalViabilityAssessment objects
    """
    assessments = []
    
    for proposal in proposals:
        profile = objection_profiles.get(proposal.id)
        objection_weight = profile.total_weight if profile else 0.0
        
        viability_score = compute_viability_score(proposal.priority, objection_weight)
        viability, reason = classify_viability(
            proposal.priority,
            objection_weight,
            viability_score,
            priority_threshold,
            poison_pill_threshold,
        )
        
        is_poison_pill = (viability == ProposalViability.POISON_PILL)
        
        assessment = ProposalViabilityAssessment(
            proposal_id=proposal.id,
            title=proposal.title,
            priority=proposal.priority,
            objection_weight=objection_weight,
            viability=viability,
            viability_score=viability_score,
            is_poison_pill=is_poison_pill,
            reason=reason,
        )
        assessments.append(assessment)
    
    logger.info('Completed viability assessment for %d proposals', len(assessments))
    return assessments


def identify_poison_pills(
    assessments: List[ProposalViabilityAssessment],
) -> List[ProposalViabilityAssessment]:
    """
    Identify all Poison Pill proposals.
    
    Args:
        assessments: List of ProposalViabilityAssessment objects
        
    Returns:
        List of assessments classified as POISON_PILL
    """
    poison_pills = [a for a in assessments if a.is_poison_pill]
    logger.info('Identified %d Poison Pill proposals', len(poison_pills))
    return poison_pills


def filter_poison_pills(
    proposals: List,
    assessments: List[ProposalViabilityAssessment],
) -> Tuple[List, List[ProposalViabilityAssessment]]:
    """
    Filter out all Poison Pill proposals from consideration.
    
    Args:
        proposals: Original list of Proposal objects
        assessments: ProposalViabilityAssessment objects for each proposal
        
    Returns:
        Tuple of (filtered_proposals, filtered_out_assessments)
    """
    assessment_by_id = {a.proposal_id: a for a in assessments}
    
    filtered_proposals = []
    filtered_out = []
    
    for proposal in proposals:
        assessment = assessment_by_id.get(proposal.id)
        if assessment is None:
            logger.warning('No viability assessment found for proposal %s; keeping', proposal.id)
            filtered_proposals.append(proposal)
            continue
        
        if assessment.is_poison_pill:
            filtered_out.append(assessment)
            logger.warning(
                'Filtering out POISON PILL: %s - %s',
                proposal.id, assessment.reason
            )
        else:
            filtered_proposals.append(proposal)
    
    logger.info('Filtered %d Poison Pills from %d proposals', len(filtered_out), len(proposals))
    return filtered_proposals, filtered_out


def get_viability_distribution(
    assessments: List[ProposalViabilityAssessment],
) -> Dict[ProposalViability, int]:
    """
    Get count of proposals in each viability category.
    
    Args:
        assessments: List of ProposalViabilityAssessment objects
        
    Returns:
        Dictionary mapping ProposalViability to count
    """
    distribution = {v: 0 for v in ProposalViability}
    
    for assessment in assessments:
        distribution[assessment.viability] += 1
    
    return distribution


def get_highest_priority_unviable(
    assessments: List[ProposalViabilityAssessment],
    exclude_viable: bool = True,
) -> List[ProposalViabilityAssessment]:
    """
    Get proposals with high priority but poor viability (candidates for rejection).
    
    Args:
        assessments: List of ProposalViabilityAssessment objects
        exclude_viable: If True, exclude VIABLE proposals (default True)
        
    Returns:
        List of assessments sorted by priority (descending)
    """
    candidates = []
    
    for assessment in assessments:
        if exclude_viable and assessment.viability == ProposalViability.VIABLE:
            continue
        if assessment.priority >= 50:  # Moderate+ priority
            candidates.append(assessment)
    
    # Sort by priority descending
    candidates.sort(key=lambda a: a.priority, reverse=True)
    return candidates


@dataclass(frozen=True)
class PoisonPillReport:
    """Summary report of Poison Pill detection and filtering."""
    total_proposals: int
    viable_count: int
    at_risk_count: int
    poison_pill_count: int
    uncontested_count: int
    poison_pills_filtered: int
    proposals_remaining: int
    avg_viability: float
    median_viability: float


def generate_poison_pill_report(
    original_proposals: List,
    filtered_proposals: List,
    assessments: List[ProposalViabilityAssessment],
    distribution: Dict[ProposalViability, int],
) -> PoisonPillReport:
    """
    Generate a comprehensive Poison Pill report.
    
    Args:
        original_proposals: Original proposal list
        filtered_proposals: Proposals after filtering
        assessments: All ProposalViabilityAssessment objects
        distribution: Result from get_viability_distribution()
        
    Returns:
        PoisonPillReport with statistics
    """
    viability_scores = [a.viability_score for a in assessments]
    viability_scores_sorted = sorted(viability_scores)
    
    avg_viability = sum(viability_scores) / len(viability_scores) if viability_scores else 0.0
    median_idx = len(viability_scores_sorted) // 2
    median_viability = viability_scores_sorted[median_idx] if viability_scores_sorted else 0.0
    
    return PoisonPillReport(
        total_proposals=len(original_proposals),
        viable_count=distribution[ProposalViability.VIABLE],
        at_risk_count=distribution[ProposalViability.AT_RISK],
        poison_pill_count=distribution[ProposalViability.POISON_PILL],
        uncontested_count=distribution[ProposalViability.UNCONTESTED],
        poison_pills_filtered=len(original_proposals) - len(filtered_proposals),
        proposals_remaining=len(filtered_proposals),
        avg_viability=avg_viability,
        median_viability=median_viability,
    )


def print_poison_pill_report(report: PoisonPillReport):
    """Print a formatted Poison Pill report."""
    print("\n=== Poison Pill Detection Report ===")
    print(f"Total proposals: {report.total_proposals}")
    print(f"\nViability distribution:")
    print(f"  VIABLE:       {report.viable_count}")
    print(f"  AT_RISK:      {report.at_risk_count}")
    print(f"  POISON_PILL:  {report.poison_pill_count}")
    print(f"  UNCONTESTED:  {report.uncontested_count}")
    print(f"\nFiltering results:")
    print(f"  Poison Pills filtered:    {report.poison_pills_filtered}")
    print(f"  Proposals remaining:      {report.proposals_remaining}")
    print(f"\nViability score statistics:")
    print(f"  Average:  {report.avg_viability:.3f}")
    print(f"  Median:   {report.median_viability:.3f}")


def get_highest_objection_proposals(
    assessments: List[ProposalViabilityAssessment],
    top_n: int = 10,
) -> List[ProposalViabilityAssessment]:
    """
    Get proposals with highest objection weights (most contested).
    
    Args:
        assessments: List of ProposalViabilityAssessment objects
        top_n: Number of top proposals to return
        
    Returns:
        List of top N proposals sorted by objection weight (descending)
    """
    sorted_assessments = sorted(
        assessments,
        key=lambda a: a.objection_weight,
        reverse=True
    )
    return sorted_assessments[:top_n]


def get_high_priority_low_viability(
    assessments: List[ProposalViabilityAssessment],
    min_priority: float = 60.0,
    max_viability: float = 0.5,
) -> List[ProposalViabilityAssessment]:
    """
    Get proposals with high priority but suspiciously low viability.
    These are prime candidates for being Poison Pills.
    
    Args:
        assessments: List of ProposalViabilityAssessment objects
        min_priority: Minimum priority to consider (default 60)
        max_viability: Maximum viability threshold (default 0.5)
        
    Returns:
        List of suspicious proposals sorted by priority (descending)
    """
    candidates = [
        a for a in assessments
        if a.priority >= min_priority and a.viability_score <= max_viability
    ]
    
    candidates.sort(key=lambda a: a.priority, reverse=True)
    return candidates
