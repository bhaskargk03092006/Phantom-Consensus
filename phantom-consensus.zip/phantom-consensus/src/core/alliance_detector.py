import logging
from typing import List, Dict, Set, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class AllianceStrength(Enum):
    """Strength classification of an alliance."""
    STRONG = "strong"          # Both representatives highly reliable to each other
    MODERATE = "moderate"      # Both mutually reliable, acceptable for partnership
    WEAK = "weak"             # Present but not particularly strong


@dataclass(frozen=True)
class Alliance:
    """A verified alliance between two or more representatives."""
    members: Tuple[str, ...]  # Sorted tuple of representative IDs (immutable)
    strength: AllianceStrength
    avg_reliability: float     # Average reliability across all members' mutual relationships
    size: int = field(init=False)  # Size of alliance
    
    def __post_init__(self):
        # Calculate size (workaround for frozen dataclass)
        object.__setattr__(self, 'size', len(self.members))


@dataclass(frozen=True)
class MutualRelationshipScore:
    """Reliability score between two representatives (bidirectional)."""
    rep_a_id: str
    rep_b_id: str
    reliability_a_to_b: float
    reliability_b_to_a: float
    mutual_reliability: float  # Average of both directions
    is_symmetric: bool         # Whether scores are similar (within tolerance)


def build_mutual_relationships(
    computed_relationships: List,
) -> Dict[Tuple[str, str], MutualRelationshipScore]:
    """
    Build a map of bidirectional relationships from computed relationships.
    
    Args:
        computed_relationships: List of ComputedRelationship objects from relationship_scorer
        
    Returns:
        Dictionary mapping (rep_a, rep_b) tuple to MutualRelationshipScore
        Keys are always ordered so rep_a < rep_b (alphabetically)
    """
    # First, index relationships by direction
    forward: Dict[Tuple[str, str], float] = {}
    for rel in computed_relationships:
        pair = (rel.representative_a_id, rel.representative_b_id)
        forward[pair] = rel.reliability_score
    
    # Now build mutual relationships
    mutual: Dict[Tuple[str, str], MutualRelationshipScore] = {}
    
    for rel in computed_relationships:
        rep_a = rel.representative_a_id
        rep_b = rel.representative_b_id
        
        # Canonicalize the pair (smaller ID first)
        canonical = (min(rep_a, rep_b), max(rep_a, rep_b))
        
        if canonical in mutual:
            continue  # Already processed this pair
        
        # Get reliability in both directions
        forward_key = (rep_a, rep_b)
        backward_key = (rep_b, rep_a)
        
        reliability_a_to_b = forward.get(forward_key, 0.0)
        reliability_b_to_a = forward.get(backward_key, 0.0)
        
        mutual_rel = (reliability_a_to_b + reliability_b_to_a) / 2.0
        
        # Check if symmetric (both sides similar)
        is_symmetric = abs(reliability_a_to_b - reliability_b_to_a) < 0.15  # Within 15%
        
        score = MutualRelationshipScore(
            rep_a_id=canonical[0],
            rep_b_id=canonical[1],
            reliability_a_to_b=reliability_a_to_b,
            reliability_b_to_a=reliability_b_to_a,
            mutual_reliability=mutual_rel,
            is_symmetric=is_symmetric,
        )
        mutual[canonical] = score
    
    logger.info('Built %d mutual relationship scores', len(mutual))
    return mutual


def detect_pairwise_alliances(
    mutual_relationships: Dict[Tuple[str, str], MutualRelationshipScore],
    min_reliability: float = 0.6,
) -> List[Alliance]:
    """
    Detect alliances between pairs of representatives.
    
    Args:
        mutual_relationships: Dictionary from build_mutual_relationships()
        min_reliability: Minimum mutual reliability to form an alliance (default 0.6)
        
    Returns:
        List of 2-member Alliance objects
    """
    alliances = []
    
    for (rep_a, rep_b), score in mutual_relationships.items():
        if score.mutual_reliability >= min_reliability:
            # Classify strength
            if score.mutual_reliability >= 0.7:
                strength = AllianceStrength.STRONG
            elif score.mutual_reliability >= 0.5:
                strength = AllianceStrength.MODERATE
            else:
                strength = AllianceStrength.WEAK
            
            alliance = Alliance(
                members=(rep_a, rep_b),
                strength=strength,
                avg_reliability=score.mutual_reliability,
            )
            alliances.append(alliance)
    
    logger.info('Detected %d pairwise alliances', len(alliances))
    return alliances


def build_alliance_graph(
    pairwise_alliances: List[Alliance],
) -> Dict[str, Set[str]]:
    """
    Build an adjacency graph of alliance relationships.
    
    Args:
        pairwise_alliances: List of 2-member Alliance objects
        
    Returns:
        Dictionary mapping representative ID to set of allied representative IDs
    """
    graph: Dict[str, Set[str]] = {}
    
    for alliance in pairwise_alliances:
        rep_a, rep_b = alliance.members
        
        if rep_a not in graph:
            graph[rep_a] = set()
        if rep_b not in graph:
            graph[rep_b] = set()
        
        graph[rep_a].add(rep_b)
        graph[rep_b].add(rep_a)
    
    return graph


def find_alliance_clusters(
    alliance_graph: Dict[str, Set[str]],
    min_cluster_size: int = 2,
) -> List[frozenset]:
    """
    Find clusters of representatives who form connected alliances.
    Uses depth-first search to find connected components.
    
    Args:
        alliance_graph: Adjacency graph from build_alliance_graph()
        min_cluster_size: Minimum members to classify as a cluster (default 2)
        
    Returns:
        List of frozensets, each containing IDs of allied representatives
    """
    visited: Set[str] = set()
    clusters: List[frozenset] = []
    
    def dfs(node: str, cluster: Set[str]):
        if node in visited:
            return
        visited.add(node)
        cluster.add(node)
        
        for neighbor in alliance_graph.get(node, set()):
            if neighbor not in visited:
                dfs(neighbor, cluster)
    
    for node in alliance_graph:
        if node not in visited:
            cluster: Set[str] = set()
            dfs(node, cluster)
            
            if len(cluster) >= min_cluster_size:
                clusters.append(frozenset(cluster))
    
    logger.info('Found %d alliance clusters', len(clusters))
    return clusters


def classify_cluster_strength(
    cluster: frozenset,
    mutual_relationships: Dict[Tuple[str, str], MutualRelationshipScore],
) -> float:
    """
    Compute average alliance strength within a cluster.
    
    Args:
        cluster: Set of representative IDs in the cluster
        mutual_relationships: Mutual relationship scores
        
    Returns:
        Average mutual reliability of all pairs in the cluster
    """
    members = sorted(cluster)
    pair_scores = []
    
    for i, rep_a in enumerate(members):
        for rep_b in members[i+1:]:
            key = (min(rep_a, rep_b), max(rep_a, rep_b))
            if key in mutual_relationships:
                pair_scores.append(mutual_relationships[key].mutual_reliability)
    
    if not pair_scores:
        return 0.0
    
    return sum(pair_scores) / len(pair_scores)


def detect_alliance_blocks(
    pairwise_alliances: List[Alliance],
    mutual_relationships: Dict[Tuple[str, str], MutualRelationshipScore],
) -> List[Alliance]:
    """
    Detect larger alliance blocks (3+ members) from pairwise alliances.
    
    Args:
        pairwise_alliances: List of 2-member Alliance objects
        mutual_relationships: Mutual relationship scores
        
    Returns:
        List of multi-member Alliance objects (3+ members)
    """
    graph = build_alliance_graph(pairwise_alliances)
    clusters = find_alliance_clusters(graph, min_cluster_size=3)
    
    blocks = []
    for cluster in clusters:
        strength_score = classify_cluster_strength(cluster, mutual_relationships)
        
        if strength_score >= 0.7:
            strength = AllianceStrength.STRONG
        elif strength_score >= 0.5:
            strength = AllianceStrength.MODERATE
        else:
            strength = AllianceStrength.WEAK
        
        block = Alliance(
            members=tuple(sorted(cluster)),
            strength=strength,
            avg_reliability=strength_score,
        )
        blocks.append(block)
    
    logger.info('Detected %d alliance blocks (3+ members)', len(blocks))
    return blocks


def detect_all_alliances(
    computed_relationships: List,
    min_reliability: float = 0.6,
) -> Tuple[List[Alliance], List[Alliance]]:
    """
    Complete alliance detection: find both pairwise and block alliances.
    
    Args:
        computed_relationships: List of ComputedRelationship objects
        min_reliability: Minimum mutual reliability threshold
        
    Returns:
        Tuple of (pairwise_alliances, alliance_blocks)
    """
    mutual_rels = build_mutual_relationships(computed_relationships)
    pairwise = detect_pairwise_alliances(mutual_rels, min_reliability)
    blocks = detect_alliance_blocks(pairwise, mutual_rels)
    
    return pairwise, blocks


def get_alliance_representatives(
    alliances: List[Alliance],
) -> Set[str]:
    """
    Get all representative IDs that are part of any alliance.
    
    Args:
        alliances: List of Alliance objects
        
    Returns:
        Set of representative IDs in alliances
    """
    members = set()
    for alliance in alliances:
        members.update(alliance.members)
    return members


def get_alliances_for_representative(
    rep_id: str,
    alliances: List[Alliance],
) -> List[Alliance]:
    """
    Get all alliances involving a specific representative.
    
    Args:
        rep_id: The representative ID to search for
        alliances: List of Alliance objects
        
    Returns:
        List of alliances containing this representative
    """
    return [a for a in alliances if rep_id in a.members]


def get_strongest_alliances(
    alliances: List[Alliance],
    top_n: int = 10,
) -> List[Alliance]:
    """
    Get the strongest alliances by average reliability.
    
    Args:
        alliances: List of Alliance objects
        top_n: Number of top alliances to return
        
    Returns:
        List of top N alliances sorted by strength (descending)
    """
    sorted_alliances = sorted(
        alliances,
        key=lambda a: (a.strength.value == AllianceStrength.STRONG.value, a.avg_reliability),
        reverse=True
    )
    return sorted_alliances[:top_n]


@dataclass(frozen=True)
class AllianceReport:
    """Summary report of detected alliances."""
    total_alliances: int
    pairwise_alliances: int
    alliance_blocks: int
    strong_alliances: int
    moderate_alliances: int
    weak_alliances: int
    members_in_alliances: int
    avg_alliance_strength: float


def generate_alliance_report(
    pairwise_alliances: List[Alliance],
    alliance_blocks: List[Alliance],
    representative_count: int,
) -> AllianceReport:
    """
    Generate a comprehensive alliance report.
    
    Args:
        pairwise_alliances: List of 2-member alliances
        alliance_blocks: List of 3+ member alliances
        representative_count: Total representatives in the system
        
    Returns:
        AllianceReport with statistics
    """
    all_alliances = pairwise_alliances + alliance_blocks
    
    members = get_alliance_representatives(all_alliances)
    
    strong = sum(1 for a in all_alliances if a.strength == AllianceStrength.STRONG)
    moderate = sum(1 for a in all_alliances if a.strength == AllianceStrength.MODERATE)
    weak = sum(1 for a in all_alliances if a.strength == AllianceStrength.WEAK)
    
    avg_strength = sum(a.avg_reliability for a in all_alliances) / len(all_alliances) if all_alliances else 0.0
    
    return AllianceReport(
        total_alliances=len(all_alliances),
        pairwise_alliances=len(pairwise_alliances),
        alliance_blocks=len(alliance_blocks),
        strong_alliances=strong,
        moderate_alliances=moderate,
        weak_alliances=weak,
        members_in_alliances=len(members),
        avg_alliance_strength=avg_strength,
    )


def print_alliance_report(report: AllianceReport, total_representatives: int):
    """Print a formatted alliance report."""
    print("\n=== Alliance Detection Report ===")
    print(f"Total alliances detected: {report.total_alliances}")
    print(f"  Pairwise (2 members):  {report.pairwise_alliances}")
    print(f"  Blocks (3+ members):   {report.alliance_blocks}")
    print(f"\nAlliance strength distribution:")
    print(f"  STRONG:    {report.strong_alliances}")
    print(f"  MODERATE:  {report.moderate_alliances}")
    print(f"  WEAK:      {report.weak_alliances}")
    print(f"\nRepresentative participation:")
    print(f"  In alliances:  {report.members_in_alliances} / {total_representatives}")
    print(f"  Unaligned:     {total_representatives - report.members_in_alliances}")
    print(f"\nAverage alliance strength: {report.avg_alliance_strength:.3f}")
