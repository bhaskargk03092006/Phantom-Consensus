import logging
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class WeightedObjection:
    """An objection with computed weight based on severity and influence."""
    proposal_id: str
    representative_id: str
    severity: float
    representative_influence: float
    weight: float  # severity * influence (normalized)
    

@dataclass(frozen=True)
class ProposalObjectionProfile:
    """Aggregated objection metrics for a single proposal."""
    proposal_id: str
    total_objections: int
    total_weight: float
    average_weight: float
    max_weight: float
    min_weight: float
    influential_objectors: int  # Count of objectors with influence > 0
    high_severity_objections: int  # Count where severity >= 70
    median_weight: float


def compute_objection_weight(
    severity: float,
    representative_influence: float,
    normalize: bool = True,
) -> float:
    """
    Compute the weight of a single objection.
    
    Weight = severity * representative_influence
    
    Both inputs are normalized to [0, 1], so the result is also in [0, 1].
    
    Args:
        severity: Objection severity (0-100, will be normalized to 0-1)
        representative_influence: Influence of objecting representative (0-100, will be normalized to 0-1)
        normalize: If True, normalize inputs from [0-100] to [0-1] (default True)
        
    Returns:
        Objection weight (0-1)
    """
    if normalize:
        # Convert from [0, 100] to [0, 1]
        sev_norm = min(1.0, max(0.0, severity / 100.0))
        inf_norm = min(1.0, max(0.0, representative_influence / 100.0))
    else:
        sev_norm = severity
        inf_norm = representative_influence
    
    weight = sev_norm * inf_norm
    return min(1.0, max(0.0, weight))


def compute_weighted_objections(
    objections: List,
    representative_index: Dict[str, any],
) -> List[WeightedObjection]:
    """
    Compute weights for all objections based on representative influence.
    
    Args:
        objections: List of Objection objects from objections_loader
        representative_index: Dictionary mapping representative IDs to Representative objects
        
    Returns:
        List of WeightedObjection objects
    """
    weighted = []
    
    for objection in objections:
        # Look up representative influence
        representative = representative_index.get(objection.representative_id)
        if representative is None:
            logger.warning(
                'Objection by unknown representative %s to proposal %s; using 0 influence',
                objection.representative_id, objection.proposal_id
            )
            influence = 0.0
        else:
            influence = representative.influence
        
        weight = compute_objection_weight(objection.severity, influence)
        
        weighted_obj = WeightedObjection(
            proposal_id=objection.proposal_id,
            representative_id=objection.representative_id,
            severity=objection.severity,
            representative_influence=influence,
            weight=weight,
        )
        weighted.append(weighted_obj)
    
    logger.info('Computed weights for %d objections', len(weighted))
    return weighted


def aggregate_objection_weights(
    weighted_objections: List[WeightedObjection],
) -> Dict[str, ProposalObjectionProfile]:
    """
    Aggregate objection weights by proposal.
    
    Args:
        weighted_objections: List of WeightedObjection objects
        
    Returns:
        Dictionary mapping proposal IDs to ProposalObjectionProfile
    """
    by_proposal: Dict[str, List[WeightedObjection]] = {}
    
    for obj in weighted_objections:
        if obj.proposal_id not in by_proposal:
            by_proposal[obj.proposal_id] = []
        by_proposal[obj.proposal_id].append(obj)
    
    profiles: Dict[str, ProposalObjectionProfile] = {}
    
    for proposal_id, objections in by_proposal.items():
        weights = [obj.weight for obj in objections]
        weights_sorted = sorted(weights)
        
        total_weight = sum(weights)
        avg_weight = total_weight / len(weights) if weights else 0.0
        
        influential_count = sum(1 for obj in objections if obj.representative_influence > 0)
        high_severity_count = sum(1 for obj in objections if obj.severity >= 70)
        
        median_idx = len(weights_sorted) // 2
        median_weight = weights_sorted[median_idx] if weights_sorted else 0.0
        
        profile = ProposalObjectionProfile(
            proposal_id=proposal_id,
            total_objections=len(objections),
            total_weight=total_weight,
            average_weight=avg_weight,
            max_weight=max(weights) if weights else 0.0,
            min_weight=min(weights) if weights else 0.0,
            influential_objectors=influential_count,
            high_severity_objections=high_severity_count,
            median_weight=median_weight,
        )
        profiles[proposal_id] = profile
    
    logger.info('Aggregated objection weights for %d proposals', len(profiles))
    return profiles


def get_objection_threats(
    proposal_profiles: Dict[str, ProposalObjectionProfile],
    weight_threshold: float = 0.5,
) -> List[Tuple[str, float]]:
    """
    Identify proposals with significant objection threats.
    
    Args:
        proposal_profiles: Dictionary from aggregate_objection_weights()
        weight_threshold: Minimum aggregate weight to consider threatening (default 0.5)
        
    Returns:
        List of (proposal_id, total_weight) tuples, sorted by threat level (descending)
    """
    threats = [
        (pid, profile.total_weight)
        for pid, profile in proposal_profiles.items()
        if profile.total_weight >= weight_threshold
    ]
    
    # Sort by threat level (highest first)
    threats.sort(key=lambda x: x[1], reverse=True)
    return threats


def get_objectors_for_proposal(
    weighted_objections: List[WeightedObjection],
    proposal_id: str,
) -> List[Tuple[str, float]]:
    """
    Get all objectors for a specific proposal, sorted by objection weight.
    
    Args:
        weighted_objections: List of WeightedObjection objects
        proposal_id: The proposal to analyze
        
    Returns:
        List of (representative_id, weight) tuples sorted by weight (descending)
    """
    objectors = [
        (obj.representative_id, obj.weight)
        for obj in weighted_objections
        if obj.proposal_id == proposal_id
    ]
    
    objectors.sort(key=lambda x: x[1], reverse=True)
    return objectors


@dataclass(frozen=True)
class ObjectionWeightReport:
    """Summary statistics for objection weighting."""
    total_objections: int
    total_proposals_objected: int
    avg_proposal_weight: float
    median_proposal_weight: float
    max_proposal_weight: float
    proposals_with_high_threat: int  # Aggregate weight >= 0.5


def generate_objection_report(
    proposal_profiles: Dict[str, ProposalObjectionProfile],
) -> ObjectionWeightReport:
    """
    Generate a report of objection weighting statistics.
    
    Args:
        proposal_profiles: Dictionary from aggregate_objection_weights()
        
    Returns:
        ObjectionWeightReport with statistics
    """
    if not proposal_profiles:
        return ObjectionWeightReport(
            total_objections=0,
            total_proposals_objected=0,
            avg_proposal_weight=0.0,
            median_proposal_weight=0.0,
            max_proposal_weight=0.0,
            proposals_with_high_threat=0,
        )
    
    weights = [profile.total_weight for profile in proposal_profiles.values()]
    weights_sorted = sorted(weights)
    
    total_objections = sum(profile.total_objections for profile in proposal_profiles.values())
    high_threat_count = sum(1 for w in weights if w >= 0.5)
    
    median_idx = len(weights_sorted) // 2
    median_weight = weights_sorted[median_idx] if weights_sorted else 0.0
    
    return ObjectionWeightReport(
        total_objections=total_objections,
        total_proposals_objected=len(proposal_profiles),
        avg_proposal_weight=sum(weights) / len(weights) if weights else 0.0,
        median_proposal_weight=median_weight,
        max_proposal_weight=max(weights) if weights else 0.0,
        proposals_with_high_threat=high_threat_count,
    )


def print_objection_report(report: ObjectionWeightReport):
    """Print a formatted objection weighting report."""
    print("\n=== Objection Weight Report ===")
    print(f"Total objections recorded: {report.total_objections}")
    print(f"Proposals with objections: {report.total_proposals_objected}")
    print(f"\nAggregate objection weight statistics:")
    print(f"  Average:  {report.avg_proposal_weight:.3f}")
    print(f"  Median:   {report.median_proposal_weight:.3f}")
    print(f"  Max:      {report.max_proposal_weight:.3f}")
    print(f"\nProposals with high threat (≥0.5): {report.proposals_with_high_threat}")


def classify_objection_impact(total_weight: float) -> str:
    """
    Classify the impact level of objections against a proposal.
    
    Args:
        total_weight: Aggregate objection weight (0-1)
        
    Returns:
        Impact classification: CRITICAL, SEVERE, MODERATE, MINOR, NONE
    """
    if total_weight >= 0.8:
        return "CRITICAL"
    elif total_weight >= 0.6:
        return "SEVERE"
    elif total_weight >= 0.4:
        return "MODERATE"
    elif total_weight >= 0.2:
        return "MINOR"
    else:
        return "NONE"
