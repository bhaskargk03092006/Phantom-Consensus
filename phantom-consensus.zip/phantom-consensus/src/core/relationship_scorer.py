import logging
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class RelationshipStrength(Enum):
    """Classification of relationship reliability."""
    STRONG = "strong"           # High trust, low betrayal
    MODERATE = "moderate"       # Decent trust, acceptable betrayal risk
    WEAK = "weak"              # Low trust or high betrayal risk
    UNSTABLE = "unstable"      # Very high betrayal probability


@dataclass(frozen=True)
class ComputedRelationship:
    """A relationship with computed reliability metrics."""
    representative_a_id: str
    representative_b_id: str
    trust: float
    rivalry: float
    betrayal_probability: float
    reliability_score: float  # Consolidated metric: trust * (1 - betrayal_probability)
    strength: RelationshipStrength
    is_mutual: bool = False  # Will be set during mutual analysis


def compute_reliability_score(
    trust: float,
    betrayal_probability: float,
    trust_weight: float = 1.0,
    betrayal_weight: float = 1.0,
) -> float:
    """
    Compute a consolidated reliability score from trust and betrayal probability.
    
    Formula: reliability = trust * (1 - betrayal_probability)
    
    This ensures that:
    - High trust with low betrayal = high reliability
    - High trust with high betrayal = low reliability (trust is undermined by risk)
    - Low trust regardless of betrayal = low reliability
    
    Args:
        trust: Trust score (0-1)
        betrayal_probability: Probability of betrayal (0-1)
        trust_weight: Weight for trust component (default 1.0)
        betrayal_weight: Weight for betrayal component (default 1.0)
        
    Returns:
        Reliability score (0-1)
    """
    if trust < 0 or trust > 1:
        logger.warning('Trust score %f is out of range [0, 1]', trust)
        trust = max(0.0, min(1.0, trust))
    
    if betrayal_probability < 0 or betrayal_probability > 1:
        logger.warning('Betrayal probability %f is out of range [0, 1]', betrayal_probability)
        betrayal_probability = max(0.0, min(1.0, betrayal_probability))
    
    reliability = trust * (1.0 - betrayal_probability)
    return max(0.0, min(1.0, reliability))


def classify_strength(
    reliability_score: float,
    strong_threshold: float = 0.7,
    moderate_threshold: float = 0.4,
    betrayal_danger_threshold: float = 0.8,
) -> RelationshipStrength:
    """
    Classify relationship strength based on reliability score.
    
    Args:
        reliability_score: Computed reliability score (0-1)
        strong_threshold: Minimum score for STRONG (default 0.7)
        moderate_threshold: Minimum score for MODERATE (default 0.4)
        betrayal_danger_threshold: If betrayal > this, flags as UNSTABLE (default 0.8)
        
    Returns:
        RelationshipStrength classification
    """
    if reliability_score >= strong_threshold:
        return RelationshipStrength.STRONG
    elif reliability_score >= moderate_threshold:
        return RelationshipStrength.MODERATE
    else:
        return RelationshipStrength.WEAK


def compute_relationship_scores(
    relationships: List,
) -> List[ComputedRelationship]:
    """
    Compute reliability scores for all relationships.
    
    Args:
        relationships: List of Relationship objects from relations_loader
        
    Returns:
        List of ComputedRelationship objects with scores
    """
    computed = []
    for rel in relationships:
        reliability = compute_reliability_score(rel.trust, rel.betrayal_probability)
        strength = classify_strength(reliability)
        
        # Flag as unstable if betrayal probability is very high
        if rel.betrayal_probability > 0.8:
            strength = RelationshipStrength.UNSTABLE
        
        computed_rel = ComputedRelationship(
            representative_a_id=rel.representative_a_id,
            representative_b_id=rel.representative_b_id,
            trust=rel.trust,
            rivalry=rel.rivalry,
            betrayal_probability=rel.betrayal_probability,
            reliability_score=reliability,
            strength=strength,
        )
        computed.append(computed_rel)
    
    logger.info('Computed reliability scores for %d relationships', len(computed))
    return computed


def find_mutual_relationships(
    computed_relationships: List[ComputedRelationship],
    min_reliability: float = 0.5,
) -> List[Tuple[ComputedRelationship, ComputedRelationship]]:
    """
    Find pairs of relationships that are mutual (bidirectional) and both above threshold.
    
    Args:
        computed_relationships: List of ComputedRelationship objects
        min_reliability: Minimum reliability score to consider (default 0.5)
        
    Returns:
        List of tuples of (rel_a_to_b, rel_b_to_a)
    """
    # Build lookup indices
    by_directed_pair: Dict[Tuple[str, str], ComputedRelationship] = {}
    for rel in computed_relationships:
        by_directed_pair[(rel.representative_a_id, rel.representative_b_id)] = rel
    
    mutual_pairs = []
    seen = set()
    
    for rel in computed_relationships:
        pair_key = (rel.representative_a_id, rel.representative_b_id)
        reverse_key = (rel.representative_b_id, rel.representative_a_id)
        
        if pair_key in seen:
            continue
        
        # Check if reverse relationship exists and both are above threshold
        if reverse_key in by_directed_pair:
            reverse_rel = by_directed_pair[reverse_key]
            if rel.reliability_score >= min_reliability and reverse_rel.reliability_score >= min_reliability:
                mutual_pairs.append((rel, reverse_rel))
                seen.add(pair_key)
                seen.add(reverse_key)
    
    logger.info('Found %d mutual reliable relationships', len(mutual_pairs))
    return mutual_pairs


def get_strongest_connections(
    computed_relationships: List[ComputedRelationship],
    representative_id: str,
    top_n: int = 5,
) -> List[ComputedRelationship]:
    """
    Get the strongest relationships for a specific representative.
    
    Args:
        computed_relationships: List of ComputedRelationship objects
        representative_id: The representative to analyze
        top_n: Number of top relationships to return
        
    Returns:
        List of top N relationships ordered by reliability score (descending)
    """
    related = [
        rel for rel in computed_relationships
        if rel.representative_a_id == representative_id or rel.representative_b_id == representative_id
    ]
    
    # Sort by reliability score descending
    sorted_rels = sorted(related, key=lambda r: r.reliability_score, reverse=True)
    return sorted_rels[:top_n]


def group_relationships_by_strength(
    computed_relationships: List[ComputedRelationship],
) -> Dict[RelationshipStrength, List[ComputedRelationship]]:
    """
    Group relationships by their strength classification.
    
    Args:
        computed_relationships: List of ComputedRelationship objects
        
    Returns:
        Dictionary mapping RelationshipStrength to list of relationships
    """
    grouped: Dict[RelationshipStrength, List[ComputedRelationship]] = {
        strength: [] for strength in RelationshipStrength
    }
    
    for rel in computed_relationships:
        grouped[rel.strength].append(rel)
    
    return grouped


@dataclass(frozen=True)
class RelationshipScoreReport:
    """Summary of relationship scoring analysis."""
    total_relationships: int
    strong_count: int
    moderate_count: int
    weak_count: int
    unstable_count: int
    mutual_reliable_count: int
    avg_reliability: float
    median_reliability: float
    min_reliability: float
    max_reliability: float


def generate_relationship_report(
    computed_relationships: List[ComputedRelationship],
    mutual_pairs: List[Tuple[ComputedRelationship, ComputedRelationship]],
) -> RelationshipScoreReport:
    """
    Generate a comprehensive report of relationship scores.
    
    Args:
        computed_relationships: All computed relationships
        mutual_pairs: Mutual relationship pairs
        
    Returns:
        RelationshipScoreReport with statistics
    """
    grouped = group_relationships_by_strength(computed_relationships)
    
    reliability_scores = [rel.reliability_score for rel in computed_relationships]
    reliability_scores.sort()
    
    avg_reliability = sum(reliability_scores) / len(reliability_scores) if reliability_scores else 0.0
    median_idx = len(reliability_scores) // 2
    median_reliability = reliability_scores[median_idx] if reliability_scores else 0.0
    
    return RelationshipScoreReport(
        total_relationships=len(computed_relationships),
        strong_count=len(grouped[RelationshipStrength.STRONG]),
        moderate_count=len(grouped[RelationshipStrength.MODERATE]),
        weak_count=len(grouped[RelationshipStrength.WEAK]),
        unstable_count=len(grouped[RelationshipStrength.UNSTABLE]),
        mutual_reliable_count=len(mutual_pairs),
        avg_reliability=avg_reliability,
        median_reliability=median_reliability,
        min_reliability=min(reliability_scores) if reliability_scores else 0.0,
        max_reliability=max(reliability_scores) if reliability_scores else 0.0,
    )


def print_relationship_report(report: RelationshipScoreReport):
    """Print a formatted relationship score report."""
    print("\n=== Relationship Score Report ===")
    print(f"Total relationships analyzed: {report.total_relationships}")
    print(f"\nStrength distribution:")
    print(f"  STRONG:    {report.strong_count}")
    print(f"  MODERATE:  {report.moderate_count}")
    print(f"  WEAK:      {report.weak_count}")
    print(f"  UNSTABLE:  {report.unstable_count}")
    print(f"\nMutual reliable relationships (≥0.5): {report.mutual_reliable_count}")
    print(f"\nReliability score statistics:")
    print(f"  Average:  {report.avg_reliability:.3f}")
    print(f"  Median:   {report.median_reliability:.3f}")
    print(f"  Min:      {report.min_reliability:.3f}")
    print(f"  Max:      {report.max_reliability:.3f}")
