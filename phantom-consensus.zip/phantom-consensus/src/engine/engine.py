from dataclasses import dataclass, field
from collections import defaultdict
from src.parsers.representatives import Representative
from src.parsers.proposals import Proposal
from src.parsers.objections import Objection
from src.parsers.relations import Relation


# Thresholds
BETRAYAL_TROJAN_THRESHOLD = 0.60    # Issue 12: trojan horse cutoff
OBJECTION_POISON_THRESHOLD = 4000   # Issue 13: poison pill aggregate weight cutoff
ALLIANCE_SCORE_THRESHOLD = 0.65     # Issue 14: minimum score to count as allied
ASYMMETRY_RATIO_THRESHOLD = 0.55    # Issue 15: false friend trust ratio cutoff
INFILTRATOR_BETRAYAL_THRESHOLD = 0.50  # Issue 16: infiltrator within-faction betrayal


@dataclass
class RelationshipScore:
    rep_a: str
    rep_b: str
    score_a_to_b: float  # how reliably A supports B
    score_b_to_a: float  # how reliably B supports A
    is_mutual: bool


# ── Issue 10: Compute relationship scores ─────────────────────────────────

def compute_relationship_scores(relations: list[Relation]) -> dict[tuple, RelationshipScore]:
    scores = {}
    for rel in relations:
        # Score = trust normalized 0-1, heavily penalized by betrayal probability
        score_a_to_b = (rel.trust_a_to_b / 100) * (1 - rel.betrayal_prob_a)
        score_b_to_a = (rel.trust_b_to_a / 100) * (1 - rel.betrayal_prob_b)

        # Penalize high rivalry
        rivalry_penalty = rel.rivalry_score / 100
        score_a_to_b *= (1 - rivalry_penalty * 0.3)
        score_b_to_a *= (1 - rivalry_penalty * 0.3)

        is_mutual = (
            score_a_to_b >= ALLIANCE_SCORE_THRESHOLD and
            score_b_to_a >= ALLIANCE_SCORE_THRESHOLD
        )

        key = (rel.rep_a, rel.rep_b)
        scores[key] = RelationshipScore(
            rep_a=rel.rep_a,
            rep_b=rel.rep_b,
            score_a_to_b=score_a_to_b,
            score_b_to_a=score_b_to_a,
            is_mutual=is_mutual,
        )
    return scores


# ── Issue 11: Calculate objection weights ─────────────────────────────────

def calculate_objection_weights(
    objections: list[Objection],
    reps: dict[str, Representative],
) -> dict[str, float]:
    weights = defaultdict(float)
    for obj in objections:
        rep = reps.get(obj.rep_id)
        if rep:
            influence = rep.influence or 0
            weights[obj.proposal_id] += obj.severity * influence
    return dict(weights)


# ── Issue 12: Filter trojan horse representatives ─────────────────────────

def filter_trojan_horses(
    reps: dict[str, Representative],
    relations: list[Relation],
) -> tuple[dict[str, Representative], list[str]]:
    trojan_ids = set()

    for rel in relations:
        if rel.betrayal_prob_a >= BETRAYAL_TROJAN_THRESHOLD:
            trojan_ids.add(rel.rep_a)
        if rel.betrayal_prob_b >= BETRAYAL_TROJAN_THRESHOLD:
            trojan_ids.add(rel.rep_b)

    safe_reps = {rid: rep for rid, rep in reps.items() if rid not in trojan_ids}
    return safe_reps, list(trojan_ids)


# ── Issue 13: Reject poison pill proposals ────────────────────────────────

def reject_poison_pills(
    proposals: dict[str, Proposal],
    objection_weights: dict[str, float],
) -> tuple[dict[str, Proposal], list[str]]:
    viable = {}
    poison = []

    for pid, prop in proposals.items():
        weight = objection_weights.get(pid, 0)
        if weight > OBJECTION_POISON_THRESHOLD:
            poison.append(pid)
        else:
            viable[pid] = prop

    return viable, poison


# ── Issue 14: Identify genuine alliances ──────────────────────────────────

def identify_alliances(
    scores: dict[tuple, RelationshipScore],
    safe_rep_ids: set[str],
) -> list[list[str]]:
    adjacency = defaultdict(set)

    for (a, b), score in scores.items():
        if score.is_mutual and a in safe_rep_ids and b in safe_rep_ids:
            adjacency[a].add(b)
            adjacency[b].add(a)

    visited = set()
    alliances = []

    def bfs(start):
        cluster = []
        queue = [start]
        while queue:
            node = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            cluster.append(node)
            queue.extend(adjacency[node] - visited)
        return cluster

    for rep_id in safe_rep_ids:
        if rep_id not in visited and rep_id in adjacency:
            cluster = bfs(rep_id)
            if len(cluster) >= 2:
                alliances.append(sorted(cluster))

    return alliances


# ── Issue 15: Handle asymmetric trust (false friends) ─────────────────────

def detect_false_friends(scores: dict[tuple, RelationshipScore]) -> list[tuple]:
    false_friends = []
    for (a, b), score in scores.items():
        total = score.score_a_to_b + score.score_b_to_a
        if total == 0:
            continue
        ratio = min(score.score_a_to_b, score.score_b_to_a) / max(score.score_a_to_b, score.score_b_to_a)
        if ratio < ASYMMETRY_RATIO_THRESHOLD:
            false_friends.append((a, b))
    return false_friends


# ── Issue 16: Uncover faction infiltrators ────────────────────────────────

def detect_infiltrators(
    reps: dict[str, Representative],
    relations: list[Relation],
) -> list[str]:
    faction_map = defaultdict(list)
    for rid, rep in reps.items():
        faction_map[rep.faction].append(rid)

    rep_betrayal = defaultdict(list)
    for rel in relations:
        rep_betrayal[rel.rep_a].append((rel.rep_b, rel.betrayal_prob_a))
        rep_betrayal[rel.rep_b].append((rel.rep_a, rel.betrayal_prob_b))

    infiltrators = []
    for rid, rep in reps.items():
        faction_members = set(faction_map[rep.faction]) - {rid}
        for target_id, prob in rep_betrayal.get(rid, []):
            if target_id in faction_members and prob >= INFILTRATOR_BETRAYAL_THRESHOLD:
                if rid not in infiltrators:
                    infiltrators.append(rid)
    return infiltrators


# ── Issue 17: Formulate consensus output ──────────────────────────────────

def build_consensus(
    reps: dict[str, Representative],
    proposals: dict[str, Proposal],
    objection_weights: dict[str, float],
    alliances: list[list[str]],
    trojan_ids: list[str],
    poison_ids: list[str],
    false_friends: list[tuple],
    infiltrators: list[str],
) -> dict:
    allied_rep_ids = {rid for group in alliances for rid in group}
    safe_rep_ids = set(reps.keys()) - set(infiltrators)

    supporting_reps = [
        rid for rid in safe_rep_ids
        if rid not in trojan_ids
    ]

    # Rank proposals by priority descending, normalized against objection weight
    ranked_proposals = sorted(
        proposals.values(),
        key=lambda p: p.priority - (objection_weights.get(p.id, 0) / 1000),
        reverse=True,
    )

    selected_proposals = [p.id for p in ranked_proposals]

    return {
        "selected_proposals": selected_proposals,
        "supporting_representatives": sorted(supporting_reps),
        "alliances": alliances,
        "flagged": {
            "trojan_horses": sorted(trojan_ids),
            "poison_pills": sorted(poison_ids),
            "false_friends": [list(pair) for pair in false_friends],
            "infiltrators": sorted(infiltrators),
        }
    }
