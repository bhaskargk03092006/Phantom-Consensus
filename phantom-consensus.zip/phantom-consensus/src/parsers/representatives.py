import json
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Representative:
    id: str
    name: str
    faction: str
    influence: Optional[int] = None  # raw — cleaned in issue 7


def load_representatives(path: str) -> dict[str, Representative]:
    with open(path, "r") as f:
        raw = json.load(f)

    reps = {}
    for record in raw:
        rep = Representative(
            id=record.get("id", ""),
            name=record.get("name", ""),
            faction=record.get("faction", ""),
            influence=record.get("influence"),
        )
        reps[rep.id] = rep

    return reps
