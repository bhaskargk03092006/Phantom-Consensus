import csv
from dataclasses import dataclass


@dataclass
class Relation:
    rep_a: str
    rep_b: str
    trust_a_to_b: float
    trust_b_to_a: float
    rivalry_score: float
    betrayal_prob_a: float  # prob that rep_a betrays rep_b
    betrayal_prob_b: float  # prob that rep_b betrays rep_a


def load_relations(path: str) -> list[Relation]:
    relations = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rel = Relation(
                rep_a=row["rep_a"].strip(),
                rep_b=row["rep_b"].strip(),
                trust_a_to_b=float(row["trust_a_to_b"]),
                trust_b_to_a=float(row["trust_b_to_a"]),
                rivalry_score=float(row["rivalry_score"]),
                betrayal_prob_a=float(row["betrayal_prob_a"]),
                betrayal_prob_b=float(row["betrayal_prob_b"]),
            )
            relations.append(rel)
    return relations
