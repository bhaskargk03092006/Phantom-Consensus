import json
from dataclasses import dataclass
from typing import Optional


@dataclass
class Proposal:
    id: str
    title: str
    sponsor_id: str
    priority: int


def load_proposals(path: str) -> dict[str, Proposal]:
    with open(path, "r") as f:
        raw = json.load(f)

    proposals = {}
    for record in raw:
        prop = Proposal(
            id=record.get("id", ""),
            title=record.get("title", ""),
            sponsor_id=record.get("sponsor_id", ""),
            priority=record.get("priority", 0),
        )
        proposals[prop.id] = prop

    return proposals
