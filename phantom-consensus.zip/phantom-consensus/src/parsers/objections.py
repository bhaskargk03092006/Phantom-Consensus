import json
from dataclasses import dataclass
from collections import defaultdict


@dataclass
class Objection:
    rep_id: str
    proposal_id: str
    severity: int


def load_objections(path: str) -> list[Objection]:
    with open(path, "r") as f:
        raw = json.load(f)

    objections = []
    for record in raw:
        obj = Objection(
            rep_id=record.get("rep_id", ""),
            proposal_id=record.get("proposal_id", ""),
            severity=record.get("severity", 0),
        )
        objections.append(obj)

    return objections


def index_objections_by_proposal(objections: list[Objection]) -> dict[str, list[Objection]]:
    index = defaultdict(list)
    for obj in objections:
        index[obj.proposal_id].append(obj)
    return dict(index)
