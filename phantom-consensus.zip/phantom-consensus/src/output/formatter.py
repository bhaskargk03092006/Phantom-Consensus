import json
import os


def format_output(consensus: dict, output_path: str) -> None:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    output = {
        "final_agreement": {
            "selected_proposals": consensus["selected_proposals"],
            "supporting_representatives": consensus["supporting_representatives"],
        },
        "detected_alliances": consensus["alliances"],
        "flagged_risks": consensus["flagged"],
    }

    with open(output_path, "w") as f:
        json.dump(output, f, indent=2)

    print(f"[OUTPUT] Written to {output_path}")
    return output
