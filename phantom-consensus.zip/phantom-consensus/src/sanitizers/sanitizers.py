from src.parsers.representatives import Representative
from src.parsers.proposals import Proposal
from src.parsers.objections import Objection
from src.parsers.relations import Relation


INFLUENCE_MIN = 0
INFLUENCE_MAX = 100
INFLUENCE_DEFAULT = 50


# ── Issue 6: Normalize representative IDs across all datasets ──────────────

def normalize_id(raw_id: str) -> str:
    return raw_id.strip().upper()


def normalize_rep_ids(
    reps: dict[str, Representative],
    proposals: dict[str, Proposal],
    objections: list[Objection],
    relations: list[Relation],
) -> tuple[dict, dict, list, list]:

    # Rebuild reps dict with normalized keys
    normalized_reps = {}
    for _, rep in reps.items():
        rep.id = normalize_id(rep.id)
        normalized_reps[rep.id] = rep

    # Normalize proposal sponsor IDs
    normalized_proposals = {}
    for pid, prop in proposals.items():
        prop.sponsor_id = normalize_id(prop.sponsor_id)
        normalized_proposals[pid] = prop

    # Normalize objection rep and proposal references
    for obj in objections:
        obj.rep_id = normalize_id(obj.rep_id)

    # Normalize relation rep references
    for rel in relations:
        rel.rep_a = normalize_id(rel.rep_a)
        rel.rep_b = normalize_id(rel.rep_b)

    return normalized_reps, normalized_proposals, objections, relations


# ── Issue 7: Handle invalid attribute types on influence ───────────────────

def sanitize_influence(reps: dict[str, Representative]) -> dict[str, Representative]:
    cleaned = {}
    for rid, rep in reps.items():
        raw = rep.influence
        if raw is None:
            rep.influence = INFLUENCE_DEFAULT
        else:
            try:
                val = int(raw)
                rep.influence = max(INFLUENCE_MIN, min(INFLUENCE_MAX, val))
            except (ValueError, TypeError):
                rep.influence = INFLUENCE_DEFAULT
        cleaned[rid] = rep
    return cleaned


# ── Issue 8: Deduplicate proposals ─────────────────────────────────────────

def deduplicate_proposals(proposals: dict[str, Proposal]) -> dict[str, Proposal]:
    # dict keyed by id already deduplicates by keeping last seen.
    # We re-process from raw list to keep first occurrence (most conservative).
    seen = {}
    for pid, prop in proposals.items():
        if pid not in seen:
            seen[pid] = prop
    return seen


def deduplicate_proposals_from_list(raw: list) -> dict[str, Proposal]:
    from src.parsers.proposals import Proposal
    seen = {}
    for record in raw:
        pid = record.get("id", "")
        if pid not in seen:
            seen[pid] = Proposal(
                id=pid,
                title=record.get("title", ""),
                sponsor_id=record.get("sponsor_id", ""),
                priority=record.get("priority", 0),
            )
    return seen


# ── Issue 9: Validate missing references (ghost reps, orphaned records) ────

def validate_references(
    reps: dict[str, Representative],
    proposals: dict[str, Proposal],
    objections: list[Objection],
    relations: list[Relation],
) -> tuple[dict, dict, list, list, list]:
    warnings = []
    valid_rep_ids = set(reps.keys())
    valid_prop_ids = set(proposals.keys())

    # Remove proposals whose sponsor doesn't exist
    valid_proposals = {}
    for pid, prop in proposals.items():
        if prop.sponsor_id not in valid_rep_ids:
            warnings.append(f"[WARN] Proposal '{pid}' dropped — sponsor '{prop.sponsor_id}' not found.")
        else:
            valid_proposals[pid] = prop

    # Drop objections referencing unknown reps or proposals
    valid_objections = []
    for obj in objections:
        if obj.rep_id not in valid_rep_ids:
            warnings.append(f"[WARN] Objection dropped — rep '{obj.rep_id}' not found.")
        elif obj.proposal_id not in valid_prop_ids:
            warnings.append(f"[WARN] Objection dropped — proposal '{obj.proposal_id}' not found.")
        else:
            valid_objections.append(obj)

    # Drop relations referencing unknown reps
    valid_relations = []
    for rel in relations:
        if rel.rep_a not in valid_rep_ids or rel.rep_b not in valid_rep_ids:
            warnings.append(f"[WARN] Relation '{rel.rep_a}<->{rel.rep_b}' dropped — unknown rep.")
        else:
            valid_relations.append(rel)

    return reps, valid_proposals, valid_objections, valid_relations, warnings
