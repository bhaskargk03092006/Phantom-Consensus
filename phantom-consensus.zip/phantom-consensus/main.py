import json
import time
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from src.parsers.representatives import load_representatives
from src.parsers.proposals import Proposal
from src.parsers.objections import load_objections, index_objections_by_proposal
from src.parsers.relations import load_relations
from src.sanitizers.sanitizers import (
    normalize_rep_ids,
    sanitize_influence,
    deduplicate_proposals_from_list,
    validate_references,
)
from src.engine.engine import (
    compute_relationship_scores,
    calculate_objection_weights,
    filter_trojan_horses,
    reject_poison_pills,
    identify_alliances,
    detect_false_friends,
    detect_infiltrators,
    build_consensus,
)
from src.output.formatter import format_output


def run_pipeline(data_dir: str = "data", output_path: str = "outputs/result.json"):
    start = time.time()
    print("=" * 55)
    print("  PHANTOM CONSENSUS ENGINE")
    print("=" * 55)

    # ── Issues 2–5: Parse all datasets ───────────────────────
    print("\n[PHASE 1] Parsing data...")
    reps = load_representatives(f"{data_dir}/representatives.json")
    print(f"  Representatives loaded: {len(reps)}")

    with open(f"{data_dir}/proposals.json") as f:
        raw_proposals = json.load(f)

    objections = load_objections(f"{data_dir}/objections.json")
    print(f"  Objections loaded: {len(objections)}")

    relations = load_relations(f"{data_dir}/relations.csv")
    print(f"  Relations loaded: {len(relations)}")

    # ── Issue 6: Normalize IDs ────────────────────────────────
    print("\n[PHASE 2] Sanitizing data...")
    raw_proposals_normalized = []
    for r in raw_proposals:
        r["id"] = r.get("id", "").strip().upper()
        r["sponsor_id"] = r.get("sponsor_id", "").strip().upper()
        raw_proposals_normalized.append(r)

    # ── Issue 8: Deduplicate proposals ────────────────────────
    proposals = deduplicate_proposals_from_list(raw_proposals_normalized)
    print(f"  Proposals after dedup: {len(proposals)} (raw: {len(raw_proposals)})")

    reps, proposals, objections, relations = normalize_rep_ids(
        reps, proposals, objections, relations
    )

    # ── Issue 7: Sanitize influence values ────────────────────
    reps = sanitize_influence(reps)
    print(f"  Influence values sanitized")

    # ── Issue 9: Validate references ─────────────────────────
    reps, proposals, objections, relations, warnings = validate_references(
        reps, proposals, objections, relations
    )
    for w in warnings:
        print(f"  {w}")
    print(f"  Valid proposals: {len(proposals)}, valid objections: {len(objections)}, valid relations: {len(relations)}")

    # ── Issue 10: Compute relationship scores ─────────────────
    print("\n[PHASE 3] Running consensus engine...")
    scores = compute_relationship_scores(relations)

    # ── Issue 11: Calculate objection weights ─────────────────
    objection_weights = calculate_objection_weights(objections, reps)

    # ── Issue 12: Filter trojan horses ────────────────────────
    safe_reps, trojan_ids = filter_trojan_horses(reps, relations)
    print(f"  Trojan horses detected: {trojan_ids}")

    # ── Issue 13: Reject poison pills ────────────────────────
    viable_proposals, poison_ids = reject_poison_pills(proposals, objection_weights)
    print(f"  Poison pills rejected: {poison_ids}")

    # ── Issue 14: Identify alliances ─────────────────────────
    alliances = identify_alliances(scores, set(safe_reps.keys()))
    print(f"  Alliances detected: {len(alliances)}")

    # ── Issue 15: Detect false friends ────────────────────────
    false_friends = detect_false_friends(scores)
    print(f"  False friend pairs: {len(false_friends)}")

    # ── Issue 16: Detect infiltrators ────────────────────────
    infiltrators = detect_infiltrators(safe_reps, relations)
    print(f"  Faction infiltrators: {infiltrators}")

    # ── Issue 17: Build consensus ────────────────────────────
    consensus = build_consensus(
        reps=safe_reps,
        proposals=viable_proposals,
        objection_weights=objection_weights,
        alliances=alliances,
        trojan_ids=trojan_ids,
        poison_ids=poison_ids,
        false_friends=false_friends,
        infiltrators=infiltrators,
    )

    # ── Issue 18: Format and write output ────────────────────
    print("\n[PHASE 4] Writing output...")
    result = format_output(consensus, output_path)

    elapsed = time.time() - start
    print(f"\n[DONE] Pipeline completed in {elapsed:.3f}s")
    print("=" * 55)

    # ── Issue 19: Edge case summary ──────────────────────────
    if not consensus["selected_proposals"]:
        print("[EDGE] No viable proposals remain after filtering.")
    if not consensus["alliances"]:
        print("[EDGE] No stable alliances detected.")
    if not consensus["supporting_representatives"]:
        print("[EDGE] No safe supporting representatives found.")

    return result


if __name__ == "__main__":
    run_pipeline()
