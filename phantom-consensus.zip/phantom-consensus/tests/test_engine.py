import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.parsers.representatives import Representative
from src.parsers.proposals import Proposal
from src.parsers.objections import Objection
from src.parsers.relations import Relation
from src.sanitizers.sanitizers import (
    normalize_id, sanitize_influence,
    deduplicate_proposals_from_list, validate_references,
)
from src.engine.engine import (
    compute_relationship_scores, calculate_objection_weights,
    filter_trojan_horses, reject_poison_pills,
    identify_alliances, detect_false_friends,
    detect_infiltrators,
)


def test_normalize_id():
    assert normalize_id("  rep_001  ") == "REP_001"
    assert normalize_id("REP_001") == "REP_001"
    assert normalize_id("rep_001") == "REP_001"
    print("PASS: normalize_id")


def test_sanitize_influence():
    reps = {
        "REP_001": Representative("REP_001", "A", "X", 85),
        "REP_002": Representative("REP_002", "B", "X", None),
        "REP_003": Representative("REP_003", "C", "X", "bad"),
        "REP_004": Representative("REP_004", "D", "X", 150),
        "REP_005": Representative("REP_005", "E", "X", "60"),
    }
    cleaned = sanitize_influence(reps)
    assert cleaned["REP_001"].influence == 85
    assert cleaned["REP_002"].influence == 50   # default
    assert cleaned["REP_003"].influence == 50   # bad string -> default
    assert cleaned["REP_004"].influence == 100  # clamped
    assert cleaned["REP_005"].influence == 60   # string -> int
    print("PASS: sanitize_influence")


def test_deduplicate_proposals():
    raw = [
        {"id": "PROP_001", "title": "A", "sponsor_id": "REP_001", "priority": 80},
        {"id": "PROP_002", "title": "B", "sponsor_id": "REP_002", "priority": 70},
        {"id": "PROP_001", "title": "A (dup)", "sponsor_id": "REP_001", "priority": 80},
    ]
    result = deduplicate_proposals_from_list(raw)
    assert len(result) == 2
    assert result["PROP_001"].title == "A"  # first wins
    print("PASS: deduplicate_proposals")


def test_validate_references():
    reps = {"REP_001": Representative("REP_001", "A", "X", 80)}
    proposals = {
        "PROP_001": Proposal("PROP_001", "Good", "REP_001", 70),
        "PROP_002": Proposal("PROP_002", "Ghost", "REP_999", 60),  # ghost sponsor
    }
    objections = [
        Objection("REP_001", "PROP_001", 50),
        Objection("REP_888", "PROP_001", 40),  # ghost rep
    ]
    relations = [
        Relation("REP_001", "REP_777", 80, 80, 10, 0.1, 0.1),  # ghost
    ]
    _, valid_props, valid_objs, valid_rels, warnings = validate_references(
        reps, proposals, objections, relations
    )
    assert "PROP_002" not in valid_props
    assert len(valid_objs) == 1
    assert len(valid_rels) == 0
    assert len(warnings) == 3
    print("PASS: validate_references")


def test_trojan_horse_filter():
    reps = {
        "REP_001": Representative("REP_001", "Safe", "X", 85),
        "REP_007": Representative("REP_007", "Trojan", "X", 95),
    }
    relations = [
        Relation("REP_007", "REP_001", 90, 40, 30, 0.75, 0.10),
    ]
    safe, trojans = filter_trojan_horses(reps, relations)
    assert "REP_007" in trojans
    assert "REP_007" not in safe
    assert "REP_001" in safe
    print("PASS: filter_trojan_horses")


def test_poison_pill():
    proposals = {
        "PROP_001": Proposal("PROP_001", "Safe", "REP_001", 80),
        "PROP_004": Proposal("PROP_004", "Poison", "REP_010", 95),
    }
    weights = {"PROP_001": 1000, "PROP_004": 50000}
    viable, poison = reject_poison_pills(proposals, weights)
    assert "PROP_004" in poison
    assert "PROP_001" in viable
    print("PASS: reject_poison_pills")


def test_asymmetric_trust():
    relations = [
        Relation("REP_007", "REP_001", 92, 40, 30, 0.05, 0.20),
    ]
    scores = compute_relationship_scores(relations)
    false_friends = detect_false_friends(scores)
    assert len(false_friends) > 0
    print("PASS: detect_false_friends")


def test_edge_all_rivals():
    reps = {
        "REP_001": Representative("REP_001", "A", "X", 80),
        "REP_002": Representative("REP_002", "B", "Y", 70),
    }
    relations = [
        Relation("REP_001", "REP_002", 10, 10, 95, 0.9, 0.9),
    ]
    scores = compute_relationship_scores(relations)
    alliances = identify_alliances(scores, set(reps.keys()))
    assert alliances == []
    print("PASS: edge_all_rivals")


def test_edge_single_rep_and_proposal():
    reps = {"REP_001": Representative("REP_001", "Solo", "X", 80)}
    proposals = {"PROP_001": Proposal("PROP_001", "Only", "REP_001", 70)}
    weights = {}
    viable, poison = reject_poison_pills(proposals, weights)
    assert len(viable) == 1
    print("PASS: edge_single_rep_and_proposal")


if __name__ == "__main__":
    test_normalize_id()
    test_sanitize_influence()
    test_deduplicate_proposals()
    test_validate_references()
    test_trojan_horse_filter()
    test_poison_pill()
    test_asymmetric_trust()
    test_edge_all_rivals()
    test_edge_single_rep_and_proposal()
    print("\nAll tests passed.")
